# -*- coding: utf-8 -*-
"""项目启动器：检查依赖并调用 streamlit 运行 app.py。"""

import os
import sys
import subprocess


def ensure_dependencies():
    """检查并安装依赖"""
    required = {
        "streamlit": "streamlit",
        "pandas": "pandas",
        "numpy": "numpy",
        "plotly": "plotly",
        "scipy": "scipy",
        "sklearn": "scikit-learn",
        "statsmodels": "statsmodels",
    }
    missing = []
    for import_name, pip_name in required.items():
        try:
            __import__(import_name)
        except ImportError:
            missing.append(pip_name)

    if missing:
        print(f"[INFO] 检测到缺少依赖: {', '.join(missing)}")
        print("[INFO] 正在自动安装，请稍候...")
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", "-q"] + missing
        )
        print("[INFO] 依赖安装完成。")
    else:
        print("[INFO] 依赖检查通过。")


def start_app():
    """启动 Streamlit 应用"""
    app_path = os.path.join(os.path.dirname(__file__), "app.py")
    if not os.path.exists(app_path):
        print(f"[ERROR] 未找到主程序文件: {app_path}")
        sys.exit(1)

    print("[INFO] 正在启动 山东天气数据分析平台...")
    print("[INFO] 浏览器打开后，默认地址: http://localhost:8501")
    print("-" * 50)

    subprocess.run([sys.executable, "-m", "streamlit", "run", app_path])

if __name__ == "__main__":
    ensure_dependencies()
    start_app()
