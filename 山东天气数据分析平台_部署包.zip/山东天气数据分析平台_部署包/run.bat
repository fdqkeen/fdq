@echo off
chcp 65001 >nul
echo ==========================================
echo   山东省天气数据分析可视化平台
echo ==========================================
echo 正在启动 Streamlit 应用，请稍候...
echo.

:: 检测 Python
where python >nul 2>nul
if errorlevel 1 (
    echo [错误] 未检测到 Python，请安装 Python 3.10+ 后重试。
    pause
    exit /b 1
)

:: 安装依赖（如缺失）
echo [1/2] 检查并安装依赖...
python -m pip install -r requirements.txt -q
if errorlevel 1 (
    echo [警告] 依赖安装可能未完全成功，将尝试直接启动。
)

:: 启动应用
echo [2/2] 启动应用...
echo 应用即将在浏览器中打开，默认地址：http://localhost:8501
echo.
streamlit run app.py

pause
