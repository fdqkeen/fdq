# -*- coding: utf-8 -*-
"""建模分析算法库：熵权法、TOPSIS、K-means、线性趋势、差异显著性检验。"""

import os

os.environ.setdefault("OMP_NUM_THREADS", "1")

import numpy as np
import pandas as pd
from scipy import stats


def entropy_weight(X):
    """熵权法：由信息熵 e_j 求差异系数 d_j，归一化得权重 w_j。"""
    X = np.asarray(X, dtype=float)
    n, m = X.shape
    if n < 2:
        raise ValueError("熵权法至少需要 2 个样本")

    xmin = X.min(axis=0)
    xmax = X.max(axis=0)
    Xn = (X - xmin) / (xmax - xmin + 1e-12)
    Xn = Xn + 1e-6

    P = Xn / Xn.sum(axis=0, keepdims=True)

    k = 1.0 / np.log(n)
    E = -k * (P * np.log(P)).sum(axis=0)

    d = 1.0 - E
    w = d / d.sum()

    return w, {"X_norm": Xn, "entropy": E, "diff_coef": d}


def topsis(X, weights, benefit_mask):
    """TOPSIS：由正 / 负理想解计算相对贴近度并排序。"""
    X = np.asarray(X, dtype=float)
    weights = np.asarray(weights, dtype=float)
    benefit_mask = np.asarray(benefit_mask, dtype=bool)
    n, m = X.shape

    Xp = X.copy()
    for j in range(m):
        if not benefit_mask[j]:
            Xp[:, j] = Xp[:, j].max() - Xp[:, j]

    Z = Xp / np.sqrt((Xp ** 2).sum(axis=0, keepdims=True) + 1e-12)

    V = Z * weights

    V_pos = V.max(axis=0)
    V_neg = V.min(axis=0)

    D_pos = np.sqrt(((V - V_pos) ** 2).sum(axis=1))
    D_neg = np.sqrt(((V - V_neg) ** 2).sum(axis=1))

    C = D_neg / (D_pos + D_neg + 1e-12)

    return C, {
        "X_positive": Xp, "Z": Z, "V": V,
        "V_pos": V_pos, "V_neg": V_neg,
        "D_pos": D_pos, "D_neg": D_neg,
    }


def kmeans_cluster(X, k_range=(2, 7), random_state=42):
    """K-means 聚类：标准化后按轮廓系数自动选最优 K。"""
    from sklearn.preprocessing import StandardScaler
    from sklearn.cluster import KMeans
    from sklearn.metrics import silhouette_score

    X = np.asarray(X, dtype=float)
    if len(X) < 3:
        raise ValueError("聚类至少需要 3 个样本")

    scaler = StandardScaler()
    Xs = scaler.fit_transform(X)

    scores = {}
    cache = {}
    for k in range(k_range[0], k_range[1]):
        if k >= len(X):
            continue
        km = KMeans(n_clusters=k, n_init=10, random_state=random_state)
        lb = km.fit_predict(Xs)
        if len(set(lb)) < 2:
            continue
        try:
            s = float(silhouette_score(Xs, lb))
        except Exception:  # noqa: BLE001
            s = -1.0
        scores[k] = s
        cache[k] = (km, lb)

    if not scores:
        raise ValueError("无法完成聚类，请检查是否包含 3 个以上有效样本")

    best_k = max(scores, key=scores.get)
    km, labels = cache[best_k]
    return best_k, labels, scores, Xs


def linear_trend_forecast(series, periods=3):
    """最小二乘线性拟合，并外推预测未来若干期。"""
    y = np.asarray(series, dtype=float)
    y = y[~np.isnan(y)]
    if len(y) < 3:
        raise ValueError("趋势拟合至少需要 3 个数据点")

    x = np.arange(len(y), dtype=float)
    slope, intercept, r, p, se = stats.linregress(x, y)
    fitted = slope * x + intercept

    fx = np.arange(len(y), len(y) + periods, dtype=float)
    forecast = slope * fx + intercept

    return {
        "slope": float(slope),
        "intercept": float(intercept),
        "r2": float(r ** 2),
        "p_value": float(p),
        "std_err": float(se),
        "fitted": fitted,
        "forecast": forecast,
        "x": x,
        "y": y,
        "fx": fx,
        "periods": periods,
    }


def compare_groups(group_a, group_b, alpha=0.05):
    """两组差异检验：先做正态性检验，再自动选 t 检验或 Mann-Whitney U。"""
    a = np.asarray(group_a, dtype=float)
    b = np.asarray(group_b, dtype=float)
    a = a[~np.isnan(a)]
    b = b[~np.isnan(b)]

    out = {
        "n_a": int(len(a)), "n_b": int(len(b)),
        "mean_a": float(a.mean()) if len(a) else np.nan,
        "mean_b": float(b.mean()) if len(b) else np.nan,
        "alpha": alpha,
    }

    if len(a) < 3 or len(b) < 3:
        out.update({"test": "样本量不足", "stat": np.nan, "p_value": np.nan, "significant": False})
        return out

    p_norm_a = float(stats.shapiro(a).pvalue) if len(a) <= 5000 else float(stats.normaltest(a).pvalue)
    p_norm_b = float(stats.shapiro(b).pvalue) if len(b) <= 5000 else float(stats.normaltest(b).pvalue)
    out["normality_p_a"] = p_norm_a
    out["normality_p_b"] = p_norm_b

    if p_norm_a > alpha and p_norm_b > alpha:
        p_var = float(stats.levene(a, b).pvalue)
        equal_var = p_var > alpha
        stat, p = stats.ttest_ind(a, b, equal_var=equal_var)
        out.update({
            "test": "独立样本 t 检验",
            "equal_var": bool(equal_var),
            "levene_p": p_var,
            "stat": float(stat),
            "p_value": float(p),
        })
    else:
        stat, p = stats.mannwhitneyu(a, b, alternative="two-sided")
        out.update({
            "test": "Mann-Whitney U 检验",
            "stat": float(stat),
            "p_value": float(p),
        })

    out["significant"] = bool(out["p_value"] < alpha)
    return out


def significance_mark(p_value, alpha=0.05):
    """显著性标记：*** p<0.001，** p<0.01，* p<0.05，否则 n.s.。"""
    if p_value is None or np.isnan(p_value):
        return ""
    if p_value < 0.001:
        return "***"
    if p_value < 0.01:
        return "**"
    if p_value < alpha:
        return "*"
    return "n.s."
