# -*- coding: utf-8 -*-
"""一日 · 四季 —— 山东省气象数据可视化

数据：2025 年山东省 16 地市 08:00 / 14:00 / 20:00 的温度、风速、湿度。
叙事：序·总览 → 四季 → 一日 → 山海 → 极值 → 日用 → 建模 → 数据。
"""

import io
import os
import base64
import numpy as np
import pandas as pd
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from scipy import stats
from datetime import datetime, timedelta, date

import theme
import geo
from theme import (
    PALETTE, CATEGORICAL, METRIC_SCALE,
    SCALE_TEMP, SCALE_HUMID, SCALE_WIND, SCALE_DIV, SCALE_SCORE,
    CHART_S, CHART_M, CHART_L,
)
from models import (
    entropy_weight, topsis, kmeans_cluster,
    linear_trend_forecast, compare_groups, significance_mark,
)

st.set_page_config(
    page_title="一日 · 四季 | 山东省气象数据可视化",
    page_icon="🌤️",
    layout="wide",
    initial_sidebar_state="expanded",
)

theme.inject_css()
theme.register_plotly_theme()

PLOT_CFG = {"displayModeBar": False, "responsive": True}

COLUMN_CANDIDATES = {
    "city": ["地市", "城市", "地区", "站点", "city", "地点"],
    "dt": ["资料时间", "时间", "观测时间", "日期时间", "datetime", "date", "time"],
    "temp": ["温度/气温", "温度", "气温", "temp", "temperature"],
    "wind": ["最大风速", "风速", "wind", "windspeed", "最大风速(m/s)"],
    "humidity": ["相对湿度", "湿度", "humidity", "rh", "相对湿度(%)"],
}


def guess_column(columns, candidates):
    """从候选名中智能猜测匹配的列"""
    cols = list(columns)
    for cand in candidates:
        if cand in cols:
            return cand
    lower_map = {str(c).lower(): c for c in cols}
    for cand in candidates:
        if cand.lower() in lower_map:
            return lower_map[cand.lower()]
    for cand in candidates:
        for c in cols:
            if cand in str(c):
                return c
    for cand in candidates:
        for c in cols:
            if str(c) in cand:
                return c
    return cols[0] if cols else None


def build_features(data: pd.DataFrame) -> pd.DataFrame:
    """统一特征工程：解析时间并计算派生指标"""
    df = data.copy()
    df["dt"] = pd.to_datetime(df["dt"], errors="coerce")
    df = df.dropna(subset=["dt"])
    for col in ["temp", "wind", "humidity"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=["temp", "wind", "humidity"])
    df = df[df["city"].notna()].copy()
    df["city"] = df["city"].astype(str).str.strip()

    df["date"] = df["dt"].dt.date
    df["month"] = df["dt"].dt.month
    df["hour"] = df["dt"].dt.hour
    df["dayofyear"] = df["dt"].dt.dayofyear
    df["week"] = df["dt"].dt.isocalendar().week
    df["thi"] = df["temp"] - 0.55 * (1 - df["humidity"] / 100) * (df["temp"] - 14.5)
    df["wci"] = 13.12 + 0.6215 * df["temp"] - 11.37 * (df["wind"] ** 0.16) + 0.3965 * df["temp"] * (df["wind"] ** 0.16)
    df["comfort_score"] = (
        (1 - np.abs(df["temp"] - 22.5) / 22.5).clip(0, 1) * 0.4 +
        (1 - np.abs(df["humidity"] - 55) / 55).clip(0, 1) * 0.35 +
        (1 - df["wind"] / 10).clip(0, 1) * 0.25
    ) * 100
    df["work_index"] = (
        ((df["temp"] >= 5) & (df["temp"] <= 32)).astype(float) * 0.4 +
        (df["wind"] <= 6).astype(float) * 0.3 +
        (df["humidity"] <= 85).astype(float) * 0.3
    ) * 100
    return df.reset_index(drop=True)


@st.cache_data(show_spinner=False)
def load_builtin(path: str) -> pd.DataFrame:
    """加载内置山东省数据"""
    raw = pd.read_csv(path, encoding="gbk")
    raw.columns = ["city", "dt", "temp", "wind", "humidity"]
    return build_features(raw)


def read_uploaded(file) -> pd.DataFrame:
    """读取上传的 CSV，自动尝试多种编码"""
    raw_bytes = file.getvalue()
    last_err = None
    for enc in ["utf-8-sig", "utf-8", "gbk", "gb18030"]:
        try:
            return pd.read_csv(io.BytesIO(raw_bytes), encoding=enc)
        except Exception as e:  # noqa: BLE001
            last_err = e
            continue
    raise ValueError(f"无法解析上传文件，请确认为标准 CSV 格式。错误信息：{last_err}")

CSV_PATH = os.path.join(os.path.dirname(__file__), "data.csv")

COORDS = {
    "济南市": (117.0, 36.67), "青岛市": (120.38, 36.07), "淄博市": (118.05, 36.81),
    "枣庄市": (117.32, 34.81), "东营市": (118.67, 37.43), "烟台市": (121.45, 37.46),
    "潍坊市": (119.16, 36.71), "济宁市": (116.37, 35.42), "泰安市": (117.09, 36.20),
    "威海市": (122.12, 37.51), "日照市": (119.53, 35.42), "临沂市": (118.35, 35.05),
    "德州市": (116.36, 37.43), "聊城市": (115.98, 36.46), "滨州市": (117.97, 37.38),
    "菏泽市": (115.48, 35.23),
}

COASTAL = ["青岛市", "烟台市", "威海市", "日照市"]


def classify_region(city: str) -> str:
    """区分沿海 / 内陆 / 其他（非山东地市）"""
    if city in COASTAL:
        return "沿海"
    if city in COORDS:
        return "内陆"
    return "其他"

METRIC_NAMES = {"temp": "温度", "wind": "风速", "humidity": "湿度", "thi": "舒适度", "wci": "风冷指数", "comfort_score": "舒适评分", "work_index": "作业适宜指数"}
METRIC_UNITS = {"temp": "°C", "wind": "m/s", "humidity": "%", "thi": "", "wci": "", "comfort_score": "分", "work_index": "分"}


def fmt(value, unit=""):
    return f"{value:.2f}{unit}"


def detect_anomalies_iqr(data, col):
    """基于 IQR 方法检测异常值"""
    q1, q3 = data[col].quantile([0.25, 0.75])
    iqr = q3 - q1
    lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    return data[(data[col] < lower) | (data[col] > upper)].copy()


def detect_anomalies_zscore(data, col, threshold=3):
    """基于 Z-score 检测异常值"""
    z = np.abs(stats.zscore(data[col]))
    return data[z > threshold].copy()


def get_weather_advice(temp, wind, humidity):
    """根据温湿风给出出行建议"""
    advice = []
    if temp < 5:
        advice.append("🧥 天气寒冷，建议穿厚外套、羽绒服")
    elif temp < 15:
        advice.append("🧥 天气较凉，建议穿长袖外套")
    elif temp < 25:
        advice.append("👕 气温舒适，适合穿薄长袖或T恤")
    else:
        advice.append("🩳 气温较高，建议穿轻薄透气衣物")

    if humidity > 80:
        advice.append("☂️ 湿度较高，可能降雨，建议带伞")
    elif humidity < 30:
        advice.append("💧 空气干燥，注意补水")

    if wind > 6:
        advice.append("🌬️ 风力较大，出行注意防风")

    if temp > 28 and humidity > 60:
        advice.append("🌞 闷热天气，注意防晒和防暑")
    elif temp > 30:
        advice.append("🌞 高温天气，避免正午户外活动")

    return advice


def get_work_suggestion(work_index):
    if work_index >= 80:
        return "非常适宜户外作业"
    elif work_index >= 60:
        return "基本适宜户外作业，需留意天气变化"
    elif work_index >= 40:
        return "户外作业条件一般，需做好防护"
    else:
        return "不适宜户外作业，建议调整计划"

theme.brand("一日 · 四季", "山东省气象数据可视化")

st.sidebar.subheader("数据源")
data_source = st.sidebar.radio(
    "选择数据来源",
    ["内置数据（山东16地市）", "上传自定义数据"],
    label_visibility="collapsed",
)

data_is_uploaded = data_source == "上传自定义数据"

if data_is_uploaded:
    uploaded_file = st.sidebar.file_uploader(
        "上传 CSV 文件",
        type=["csv"],
        help="支持 UTF-8 / GBK 编码。需包含：城市、时间、温度、风速、湿度列。",
    )
    if uploaded_file is None:
        st.sidebar.info("请上传 CSV 文件以开始分析")
        theme.hero(
            "DATA UPLOAD",
            "上传你的数据",
            "在左侧「数据源」中上传 CSV 文件，作品将自动完成字段识别与指标计算。",
            [],
        )
        st.markdown(
            "**数据要求**\n\n"
            "- 格式：CSV（支持 UTF-8 / GBK 编码）\n"
            "- 必须包含 5 类字段：**城市、时间、温度、风速、湿度**\n"
            "- 时间格式示例：`2025/1/1 8:00` 或 `2025-01-01 08:00`\n"
        )
        st.markdown("---")
        st.markdown("**示例数据格式**")
        sample_df = pd.DataFrame({
            "地市": ["济南市", "济南市", "青岛市"],
            "资料时间": ["2025/1/1 8:00", "2025/1/1 14:00", "2025/1/1 8:00"],
            "温度/气温": [0.5, 8.2, 1.1],
            "最大风速": [2.1, 4.5, 3.3],
            "相对湿度": [60.2, 35.1, 68.4],
        })
        st.dataframe(sample_df, use_container_width=True)
        sample_csv = sample_df.to_csv(index=False, encoding="utf-8-sig").encode("utf-8-sig")
        st.download_button(
            "下载示例 CSV 模板",
            data=sample_csv,
            file_name="sample_weather_template.csv",
            mime="text/csv",
        )
        st.stop()

    try:
        raw_upload = read_uploaded(uploaded_file)
    except Exception as e:  # noqa: BLE001
        st.error(f"文件读取失败：{e}")
        st.stop()

    if raw_upload.empty or len(raw_upload.columns) < 5:
        st.error("上传的数据为空或列数不足 5 列，请检查文件后重新上传。")
        st.stop()

    with st.sidebar.expander("字段映射设置", expanded=False):
        cols = list(raw_upload.columns)
        city_col = st.selectbox("城市列", cols, index=cols.index(guess_column(cols, COLUMN_CANDIDATES["city"])), key="map_city")
        dt_col = st.selectbox("时间列", cols, index=cols.index(guess_column(cols, COLUMN_CANDIDATES["dt"])), key="map_dt")
        temp_col = st.selectbox("温度列", cols, index=cols.index(guess_column(cols, COLUMN_CANDIDATES["temp"])), key="map_temp")
        wind_col = st.selectbox("风速列", cols, index=cols.index(guess_column(cols, COLUMN_CANDIDATES["wind"])), key="map_wind")
        hum_col = st.selectbox("湿度列", cols, index=cols.index(guess_column(cols, COLUMN_CANDIDATES["humidity"])), key="map_hum")

    mapped = raw_upload[[city_col, dt_col, temp_col, wind_col, hum_col]].copy()
    mapped.columns = ["city", "dt", "temp", "wind", "humidity"]
    df = build_features(mapped)

    if df.empty:
        st.error("数据解析后为空，请检查时间格式与数值列是否正确。")
        st.stop()

    st.sidebar.success(f"已加载 {len(df):,} 条数据")
else:
    df = load_builtin(CSV_PATH)

CITIES = sorted(df["city"].unique().tolist())
HOURS = sorted(df["hour"].unique().tolist())
MONTH_OPTIONS = sorted(df["month"].unique().tolist())
HOUR_DEFAULT = [h for h in [8, 14, 20] if h in HOURS] or HOURS

_DEFAULT_CITIES = ["济南市", "青岛市", "烟台市", "威海市", "潍坊市", "临沂市", "德州市", "菏泽市"]

selected_cities = st.sidebar.multiselect(
    "选择地市（最多 8 个）",
    CITIES,
    default=[c for c in _DEFAULT_CITIES if c in CITIES] or CITIES[: min(8, len(CITIES))],
    max_selections=8,
    help="默认选中 8 个代表性地市，兼顾沿海与内陆，使建模分析结果更具代表性。",
)

month_min, month_max = MONTH_OPTIONS[0], MONTH_OPTIONS[-1]
if month_min == month_max:
    selected_months = (month_min, month_max)
    st.sidebar.caption(f"数据仅包含 {month_min} 月")
else:
    selected_months = st.sidebar.slider(
        "选择月份范围", month_min, month_max, (month_min, month_max)
    )

selected_hours = st.sidebar.multiselect("选择观测时段", HOURS, default=HOUR_DEFAULT)

metric = st.sidebar.selectbox(
    "选择核心指标",
    ["temp", "wind", "humidity", "thi", "wci", "comfort_score", "work_index"],
    format_func=lambda x: {
        "temp": "温度 (°C)", "wind": "最大风速 (m/s)", "humidity": "相对湿度 (%)",
        "thi": "温湿舒适度指数", "wci": "风冷指数",
        "comfort_score": "综合舒适评分", "work_index": "作业适宜指数",
    }[x],
)

aggregation = st.sidebar.selectbox(
    "聚合方式", ["mean", "max", "min", "std"],
    format_func=lambda x: {"mean": "平均值", "max": "最大值", "min": "最小值", "std": "标准差"}[x],
)

st.sidebar.markdown("---")
if data_is_uploaded:
    st.sidebar.info(
        f"当前使用 **自定义数据**，共 {len(df):,} 条记录，"
        f"{len(CITIES)} 个地点，时间跨度 {df['dt'].min():%Y-%m-%d} ~ {df['dt'].max():%Y-%m-%d}。"
    )
else:
    st.sidebar.info(
        "当前使用 **内置山东省数据**（2025 全年 8/14/20 时，16 地市），"
        "按「四季—一日—山海—极值—日用—建模」诸幕组织。"
    )
    with st.sidebar.expander("想分析自己的数据？"):
        st.markdown(
            "切换上方数据源为 **「上传自定义数据」**，"
            "即可上传你自己的 CSV 文件，平台会自动完成字段识别与特征计算。"
        )
        sample_df2 = pd.DataFrame({
            "地市": ["济南市"], "资料时间": ["2025/1/1 8:00"],
            "温度/气温": [0.5], "最大风速": [2.1], "相对湿度": [60.2],
        })
        st.download_button(
            "下载 CSV 模板",
            data=sample_df2.to_csv(index=False, encoding="utf-8-sig").encode("utf-8-sig"),
            file_name="sample_weather_template.csv",
            mime="text/csv",
            key="sidebar_tpl",
        )

if not selected_cities or not selected_hours:
    st.warning("请至少选择一个地市和一个观测时段。")
    st.stop()

filtered = df[
    (df["city"].isin(selected_cities))
    & (df["month"].between(selected_months[0], selected_months[1]))
    & (df["hour"].isin(selected_hours))
].copy()

if filtered.empty:
    st.warning("当前筛选条件下无数据，请调整筛选条件。")
    st.stop()

metric_label = f"{METRIC_NAMES[metric]} ({METRIC_UNITS[metric]})" if METRIC_UNITS[metric] else METRIC_NAMES[metric]

_span = f"{df['dt'].min():%Y.%m} — {df['dt'].max():%Y.%m}"
theme.hero(
    "SHANDONG CLIMATE ATLAS · 2025",
    "一日 · 四季",
    "以山东省 16 地市全年气象观测为底本，在「一天」与「一年」两个时间尺度上，"
    "阅读温度、湿度与风如何塑造这片土地——以及生活在其间的人如何据此安排出行、劳作与休憩。",
    [
        ("观测网络", f"{df['city'].nunique()} 地市"),
        ("观测时点", "08 / 14 / 20 时"),
        ("时间跨度", _span),
        ("有效样本", f"{len(df):,}"),
    ],
)

theme.cards([
    ("当前地市", f"{len(selected_cities)}", " 个", f"共 {df['city'].nunique()} 个可选"),
    ("当前样本", f"{len(filtered):,}", " 条", f"占全量 {len(filtered)/len(df)*100:.1f}%"),
    (f"{METRIC_NAMES[metric]}均值", f"{filtered[metric].mean():.2f}", f" {METRIC_UNITS[metric]}", "当前筛选下的整体水平"),
    ("平均舒适评分", f"{filtered['comfort_score'].mean():.1f}", " 分", "温度湿度风速综合"),
], cols=4)

# tab3 / tab4 交换绑定，使「贰 · 一日」排在「叁 · 山海」之前
tab1, tab2, tab4, tab3, tab5, tab6, tab7, tab8 = st.tabs([
    "序 · 总览", "壹 · 四季", "贰 · 一日", "叁 · 山海",
    "肆 · 极值", "伍 · 日用", "陆 · 建模", "附 · 数据",
])

with tab1:
    theme.scene_header("序", "总览", "数据从何而来，覆盖什么")
    theme.lede(
        "本作品取材于山东省 16 个地市气象观测站 2025 年全年逐日记录，每日取 08:00、14:00、20:00 "
        "三个时点，覆盖温度、最大风速与相对湿度三项要素。以下全部分析均基于这套原始观测，"
        "未作平滑或插补处理。"
    )
    _t_mean, _t_max, _t_min = filtered["temp"].mean(), filtered["temp"].max(), filtered["temp"].min()
    _w_mean, _w_max = filtered["wind"].mean(), filtered["wind"].max()
    _h_mean, _h_max, _h_min = filtered["humidity"].mean(), filtered["humidity"].max(), filtered["humidity"].min()
    theme.cards([
        ("温度 · 均值", f"{_t_mean:.2f}", " °C", f"区间 {_t_min:.1f} ~ {_t_max:.1f} °C"),
        ("最大风速 · 均值", f"{_w_mean:.2f}", " m/s", f"极大值 {_w_max:.2f} m/s"),
        ("相对湿度 · 均值", f"{_h_mean:.2f}", " %", f"区间 {_h_min:.1f} ~ {_h_max:.1f} %"),
    ], cols=3)

    theme.closing(
        "本幕提示",
        "总览给出的三个均值是全部后续分析的基准线：温度约 15 °C、风速约 3 m/s、湿度约 62 %。"
        "后面七幕所做的，正是把这三个数字按时间、空间与极端情形逐层拆开——"
        "看它们如何在一年之内起落、在十六地市之间分布、又在何时越过危险阈值。",
    )

    st.subheader("城市综合排名")
    rank_df = filtered.groupby("city").agg({
        "temp": "mean", "wind": "mean", "humidity": "mean",
        "comfort_score": "mean", "work_index": "mean"
    }).round(2).reset_index()
    rank_df = rank_df.sort_values("comfort_score", ascending=False)
    fig_rank = px.bar(
        rank_df, x="comfort_score", y="city", orientation="h", color="comfort_score",
        color_continuous_scale=SCALE_SCORE, labels={"comfort_score": "舒适评分", "city": "地市"},
        height=CHART_M,
    )
    fig_rank.update_yaxes(categoryorder="total ascending")
    st.plotly_chart(theme.polish(fig_rank), use_container_width=True, config=PLOT_CFG)
    st.markdown(
        f"<div class='insight-box'><b>综合排名结论：</b><b>{rank_df.iloc[0]['city']}</b> 舒适评分最高（{rank_df.iloc[0]['comfort_score']:.2f}分），"
        f"<b>{rank_df.iloc[-1]['city']}</b> 最低（{rank_df.iloc[-1]['comfort_score']:.2f}分）。"
        f"评分综合考虑了温度适宜性、湿度舒适度和风力影响。</div>",
        unsafe_allow_html=True,
    )

    st.subheader("城市多维雷达对比")
    radar_metrics = ["temp", "wind", "humidity", "comfort_score", "work_index"]
    radar_labels = ["温度", "风速", "湿度", "舒适评分", "作业适宜"]
    radar_df = filtered.groupby("city")[radar_metrics].mean().reset_index()
    radar_norm = radar_df.copy()
    for col in radar_metrics:
        min_v, max_v = radar_df[col].min(), radar_df[col].max()
        radar_norm[col] = (radar_df[col] - min_v) / (max_v - min_v + 1e-9)

    fig_radar = go.Figure()
    for idx, row in radar_norm.iterrows():
        city = radar_df.loc[idx, "city"]
        values = row[radar_metrics].tolist()
        fig_radar.add_trace(go.Scatterpolar(
            r=values + [values[0]], theta=radar_labels + [radar_labels[0]],
            fill="toself", name=city, opacity=0.6,
        ))
    fig_radar.update_layout(
        polar=dict(radialaxis=dict(visible=True, range=[0, 1])),
        template="qilu", height=CHART_L,
        legend=dict(orientation="h", yanchor="bottom", y=-0.2),
    )
    st.plotly_chart(theme.polish(fig_radar), use_container_width=True, config=PLOT_CFG)

    theme.closing(
        "本幕小结",
        "排序回答「哪里最舒适」，雷达图回答「凭什么排名如此」。五个维度归一化后同框对比，"
        "可以看到排名靠前的城市往往不是单项最强，而是在温度、湿度、风与作业适宜度之间的"
        "均衡度更高——单一维度的突出，反而不容易换来整体舒适。",
    )

with tab2:
    theme.scene_header("壹", "四季", "十二个月的轮回")
    theme.lede(
        "山东地处暖温带季风气候区，四季分明。把 12 个月的日均值连成一条线，可以看到温度如何"
        "在一年里完成一次完整的爬升与回落——这是所有季节性生产生活节律的底层节拍。"
    )
    daily = filtered.groupby(["date", "city"])[metric].mean().reset_index()
    fig_ts = px.line(
        daily, x="date", y=metric, color="city", labels={"date": "日期", metric: metric_label, "city": "地市"},
        template="qilu", height=CHART_M,
    )
    fig_ts.update_layout(hovermode="x unified")
    st.subheader("日变化趋势")
    st.plotly_chart(theme.polish(fig_ts), use_container_width=True, config=PLOT_CFG)

    st.subheader("月度变化趋势")
    monthly = filtered.groupby(["month", "city"])[metric].mean().reset_index()
    fig_month = px.line(
        monthly, x="month", y=metric, color="city", markers=True,
        labels={"month": "月份", metric: metric_label, "city": "地市"},
        template="qilu", height=CHART_M,
    )
    fig_month.update_xaxes(type="category")
    st.plotly_chart(theme.polish(fig_month), use_container_width=True, config=PLOT_CFG)
    month_avg = monthly.groupby("month")[metric].mean()
    max_m, min_m = month_avg.idxmax(), month_avg.idxmin()
    st.markdown(
        f"<div class='insight-box'><b>月度趋势结论：</b>{metric_label}在 <b>{max_m}月</b> 达到最高（{month_avg[max_m]:.2f}），"
        f"在 <b>{min_m}月</b> 达到最低（{month_avg[min_m]:.2f}），呈现明显的季节性波动。</div>",
        unsafe_allow_html=True,
    )

    st.subheader("7 日移动平均与趋势")
    daily_all = filtered.groupby("date")[metric].mean().reset_index()
    daily_all = daily_all.sort_values("date")
    daily_all["ma7"] = daily_all[metric].rolling(window=7, min_periods=1).mean()
    daily_all["ma30"] = daily_all[metric].rolling(window=30, min_periods=1).mean()
    # 滚动平均列须改中文名，否则图例显示为 ma7 / ma30
    _ma_plot = daily_all.rename(columns={metric: "逐日实测", "ma7": "7 日移动平均", "ma30": "30 日移动平均"})
    fig_ma = px.line(
        _ma_plot, x="date", y=["逐日实测", "7 日移动平均", "30 日移动平均"],
        labels={"value": metric_label, "date": "日期", "variable": ""},
        template="qilu", height=CHART_M,
    )
    st.plotly_chart(theme.polish(fig_ma), use_container_width=True, config=PLOT_CFG)
    theme.caption("细线为逐日原始值，另两条分别为 7 日、30 日移动平均。窗口越长曲线越平滑，"
                  "也越能看清季节走向而非单日波动。")

    st.subheader("月度 × 时段联合趋势")
    season_df = filtered.groupby(["month", "hour"])[metric].mean().reset_index()
    fig_season = px.line(
        season_df, x="month", y=metric, color="hour", markers=True,
        labels={"month": "月份", metric: metric_label, "hour": "观测时段"},
        template="qilu", height=CHART_M,
    )
    fig_season.update_xaxes(type="category")
    st.plotly_chart(theme.polish(fig_season), use_container_width=True, config=PLOT_CFG)
    theme.caption("三条线分别对应 08 时、14 时、20 时三个观测时段。线与线之间的距离，"
                  "即为同日不同时刻的差异幅度。")

    theme.closing(
        "本幕小结",
        "把 12 个月连起来看，指标完成一次完整的爬升与回落；把 24 小时拆开看，同一日期之内"
        "也藏着一次微型的起伏。两条曲线叠加后可以确认：季节振幅的量级明显大于日内振幅，"
        "这正是山东季风气候「四季分明」的直接来源。",
    )

with tab3:
    theme.scene_header("叁", "山海", "沿海与内陆的对话")
    theme.lede(
        "山东半岛三面环海。海洋的热惯性使沿海城市温度变化更平缓、湿度更高，内陆城市则表现出"
        "更强的日较差与季节振幅。将两种地形放在同一坐标系下，地理对气候的塑造作用便清晰可见。"
    )
    map_df = filtered.groupby("city").agg({
        metric: "mean", "temp": "mean", "wind": "mean", "humidity": "mean", "comfort_score": "mean"
    }).reset_index()
    map_df["lon"] = map_df["city"].map(lambda c: COORDS.get(c, (None, None))[0])
    map_df["lat"] = map_df["city"].map(lambda c: COORDS.get(c, (None, None))[1])
    map_ready = map_df.dropna(subset=["lon", "lat"]).copy()
    unknown_cities = map_df[map_df["lon"].isna()]["city"].tolist()

    if map_ready.empty:
        st.info("当前数据中的地点未收录于内置经纬度库，无法绘制地图。可查看下方城市排名与热力图。")
    else:
        map_ready["size"] = np.abs(map_ready[metric]) * 2 + 6
        map_ready["label"] = map_ready["city"].str.replace("市", "", regex=False)

        fig_map = go.Figure()

        # 自绘省域底图：不依赖在线瓦片，离线可用（轮廓见 geo.py）
        for ring in geo.SHANDONG_OUTLINE:
            xs = [p[0] for p in ring] + [ring[0][0]]
            ys = [p[1] for p in ring] + [ring[0][1]]
            fig_map.add_trace(go.Scatter(
                x=xs, y=ys, mode="lines",
                fill="toself",
                fillcolor="rgba(27, 75, 90, 0.07)",
                line=dict(color=PALETTE["sea"], width=1.4),
                hoverinfo="skip", showlegend=False,
            ))

        for sea, lon, lat in [("渤海", 119.15, 38.05), ("黄海", 121.85, 35.95)]:
            fig_map.add_annotation(
                x=lon, y=lat, text=sea, showarrow=False,
                font=dict(family=theme.FONT_SERIF, size=13, color=PALETTE["muted"]),
                opacity=.75,
            )

        fig_map.add_trace(go.Scatter(
            x=map_ready["lon"], y=map_ready["lat"],
            mode="markers+text",
            text=map_ready["label"],
            textposition="top center",
            textfont=dict(family=theme.FONT_SANS, size=12, color=PALETTE["sea"]),
            marker=dict(
                size=map_ready["size"], sizemode="diameter", sizemin=8,
                color=map_ready[metric],
                colorscale=METRIC_SCALE.get(metric, SCALE_TEMP),
                showscale=True,
                colorbar=dict(
                    title=dict(text=METRIC_NAMES.get(metric, metric), side="top"),
                    thickness=10, len=0.55, outlinewidth=0,
                    x=1.0, xpad=8, ticks="outside", tickfont=dict(size=11),
                ),
                line=dict(color="#FFFFFF", width=1.2),
            ),
            customdata=map_ready[["city", "temp", "wind", "humidity", "comfort_score"]].values,
            hovertemplate=(
                "<b>%{customdata[0]}</b><br>"
                "温度 %{customdata[1]:.2f} °C<br>"
                "风速 %{customdata[2]:.2f} m/s<br>"
                "湿度 %{customdata[3]:.2f} %<br>"
                "舒适评分 %{customdata[4]:.2f}<extra></extra>"
            ),
            showlegend=False,
        ))

        lon0, lon1, lat0, lat1 = geo.bounds()
        fig_map.update_xaxes(range=[lon0 - .35, lon1 + .55], showgrid=False,
                             showticklabels=False, zeroline=False, fixedrange=True)
        fig_map.update_yaxes(range=[lat0 - .3, lat1 + .3], showgrid=False,
                             showticklabels=False, zeroline=False, fixedrange=True,
                             scaleanchor="x", scaleratio=1.18)
        fig_map.update_layout(
            height=CHART_L, template="qilu",
            margin=dict(l=10, r=10, t=16, b=10),
            plot_bgcolor="rgba(0,0,0,0)", paper_bgcolor="rgba(0,0,0,0)",
        )

        st.subheader("城市空间分布")
        st.plotly_chart(theme.polish(fig_map), use_container_width=True, config=PLOT_CFG)
        theme.caption(
            "省界为离线内嵌的行政边界轮廓（阿里云 DataV 公开数据，Douglas-Peucker 简化），"
            "不依赖在线瓦片；点大小与颜色均映射所选指标。"
        )
        if unknown_cities:
            theme.caption(f"以下地点无内置坐标，未在地图展示：{', '.join(unknown_cities)}")

    st.subheader("城市排名对比")
    city_rank = filtered.groupby("city")[metric].mean().sort_values(ascending=False).reset_index()
    fig_bar = px.bar(
        city_rank, x="city", y=metric, color=metric, color_continuous_scale=METRIC_SCALE.get(metric, SCALE_TEMP),
        labels={"city": "地市", metric: metric_label}, height=CHART_M,
    )
    st.plotly_chart(theme.polish(fig_bar), use_container_width=True, config=PLOT_CFG)

    st.subheader("沿海与内陆对比")
    filtered["region"] = filtered["city"].apply(classify_region)
    region_df = filtered.groupby(["region", "month"]).agg({
        "temp": "mean", "humidity": "mean", "wind": "mean", "comfort_score": "mean"
    }).reset_index()
    if filtered["region"].nunique() > 1:
        fig_region = px.line(
            region_df, x="month", y=metric, color="region", markers=True,
            labels={"month": "月份", metric: metric_label, "region": "区域类型"},
            template="qilu", height=CHART_M,
        )
        fig_region.update_xaxes(type="category")
        st.plotly_chart(theme.polish(fig_region), use_container_width=True, config=PLOT_CFG)
        region_avg = filtered.groupby("region")[metric].mean()
        detail = "，".join([f"{r} {v:.2f}" for r, v in region_avg.items()])
        st.markdown(
            f"<div class='insight-box'><b>区域对比结论：</b>各区域 {metric_label} 平均值为：{detail}。"
            f"沿海城市受海洋调节，温度波动通常较小，湿度相对较高。</div>",
            unsafe_allow_html=True,
        )
    else:
        st.info("当前数据仅包含单一区域类型，跳过区域对比。")

    st.subheader("城市 × 月份热力图")
    pivot = filtered.groupby(["city", "month"])[metric].mean().unstack().reindex(
        columns=range(selected_months[0], selected_months[1] + 1)
    )
    fig_heat = px.imshow(
        pivot, aspect="auto", color_continuous_scale=METRIC_SCALE.get(metric, SCALE_TEMP),
        labels={"color": metric_label, "x": "月份", "y": "地市"},
        height=CHART_L,
    )
    fig_heat.update_traces(text=pivot.round(1).values, texttemplate="%{text}", hovertemplate="%{y} %{x}月: %{z:.2f}")
    st.plotly_chart(theme.polish(fig_heat), use_container_width=True, config=PLOT_CFG)
    theme.caption("横向为 12 个月，纵向为各地市。颜色越暖代表数值越高，"
                  "同列颜色差异反映同一月份下城市间的分化程度。")

    theme.closing(
        "本幕小结",
        "地形在图上留下了清楚的痕迹。沿海城市受海洋热惯性调节，全年色带偏冷且变化平缓；"
        "内陆城市则色带跨度更大，夏更热、冬更冷。区域对比的统计检验同时给出了支撑——"
        "山海之间的分野不是观感，而是可以在数据上量出的差异。",
    )

with tab4:
    theme.scene_header("贰", "一日", "三个时刻的节奏")
    theme.lede(
        "一天之内，清晨 08:00、午后 14:00 与入夜 20:00 的气象条件差异显著。这个尺度上的变化"
        "最贴近个体体验，也直接决定了通勤、作息与户外活动的时间安排。"
    )
    hour_df = filtered.groupby(["hour", "city"])[metric].mean().reset_index()
    fig_hour = px.box(
        filtered, x="hour", y=metric, color="hour",
        labels={"hour": "观测时段", metric: metric_label},
        template="qilu", height=CHART_M,
    )
    fig_hour.update_xaxes(type="category")
    st.subheader("各时段温湿度分布")
    st.plotly_chart(theme.polish(fig_hour), use_container_width=True, config=PLOT_CFG)

    st.subheader("各城市早中晚差异")
    city_hour = filtered.groupby(["city", "hour"])[metric].mean().unstack().reset_index()
    city_hour["昼夜温差"] = city_hour[20] - city_hour[8] if 20 in city_hour.columns and 8 in city_hour.columns else 0
    fig_city_hour = px.bar(
        hour_df, x="hour", y=metric, color="city", barmode="group",
        labels={"hour": "时段", metric: metric_label, "city": "地市"},
        template="qilu", height=CHART_M,
    )
    fig_city_hour.update_xaxes(type="category")
    st.plotly_chart(theme.polish(fig_city_hour), use_container_width=True, config=PLOT_CFG)

    st.subheader("昼夜温差分析")
    if 8 in filtered["hour"].values and 20 in filtered["hour"].values:
        day_night = filtered[filtered["hour"].isin([8, 20])].groupby(["city", "date", "hour"])["temp"].mean().unstack()
        day_night["温差"] = day_night[20] - day_night[8]
        temp_range = day_night.reset_index().groupby("city")["温差"].mean().sort_values(ascending=False).reset_index()
        fig_range = px.bar(
            temp_range, x="city", y="温差", color="温差", color_continuous_scale=METRIC_SCALE.get(metric, SCALE_TEMP),
            labels={"city": "地市", "温差": "昼夜温差 (°C)"}, height=CHART_M,
        )
        st.plotly_chart(theme.polish(fig_range), use_container_width=True, config=PLOT_CFG)
        st.markdown(
            f"<div class='insight-box'><b>昼夜温差结论：</b><b>{temp_range.iloc[0]['city']}</b> 昼夜温差最大（{temp_range.iloc[0]['温差']:.2f}°C），"
            f"<b>{temp_range.iloc[-1]['city']}</b> 最小（{temp_range.iloc[-1]['温差']:.2f}°C）。沿海城市昼夜温差通常小于内陆。</div>",
            unsafe_allow_html=True,
        )
    else:
        st.info("请选择包含 8:00 和 20:00 的时段以进行昼夜温差分析。")

    theme.closing(
        "本幕小结",
        "三个观测时刻在同一日期内呈现出清晰的次序：清晨最低、午后最高、入夜回落。"
        "但真正决定体感的不只是温度本身——午后湿度往往同步走低，风力却达到日内峰值，"
        "三者叠加才构成「上午偏凉、午后干爽、傍晚回润」的日常节律。"
        "这也说明为何单看温度不足以安排户外活动，湿度与风的日内变化需要一并纳入考量。",
    )

with tab5:
    theme.scene_header("肆", "极值", "异常天气的痕迹")
    theme.lede(
        "均值描述常态，极值决定风险。高温、大风与高湿的极端事件虽然占比不高，"
        "却是生产生活中最需要提前防范的部分。"
    )
    thresholds = {
        "temp": (filtered["temp"].quantile(0.95), "高温"),
        "wind": (filtered["wind"].quantile(0.95), "大风"),
        "humidity": (filtered["humidity"].quantile(0.95), "高湿"),
    }
    for col, (thr, name) in thresholds.items():
        extreme = filtered[filtered[col] >= thr]
        if not extreme.empty:
            top = extreme.nlargest(1, col).iloc[0]
            st.markdown(
                f"<div class='warning-box'><b>{name}预警</b>：{top['city']} 在 {top['dt'].strftime('%m月%d日 %H:%M')} "
                f"出现 {top[col]:.2f} 的{name}，超过 {(filtered[col] >= thr).sum()} 次记录。</div>",
                unsafe_allow_html=True,
            )

    st.subheader("IQR 异常检测")
    anomaly_col = st.selectbox("选择异常检测指标", ["temp", "wind", "humidity"], format_func=lambda x: METRIC_NAMES[x])
    anomalies = detect_anomalies_iqr(filtered, anomaly_col)
    st.write(f"检测到 **{len(anomalies)}** 条异常记录（占总数据 {len(anomalies)/len(filtered)*100:.2f}%）")
    if not anomalies.empty:
        fig_anomaly = px.scatter(
            filtered, x="dt", y=anomaly_col, color="city", opacity=0.6,
            labels={"dt": "时间", anomaly_col: METRIC_NAMES[anomaly_col], "city": "地市"},
            height=CHART_M,
        )
        fig_anomaly.add_scatter(
            x=anomalies["dt"], y=anomalies[anomaly_col], mode="markers",
            marker=dict(color=PALETTE["danger"], size=11, symbol="x", line=dict(width=1, color="#FFFFFF")), name="异常值"
        )
        st.plotly_chart(theme.polish(fig_anomaly), use_container_width=True, config=PLOT_CFG)
        st.dataframe(anomalies[["city", "dt", anomaly_col]].sort_values(anomaly_col, ascending=False).head(20), use_container_width=True)

    theme.closing(
        "本幕小结",
        "异常检测的意义不在于列出多少条离群记录，而在于确认极端值并非随机噪声——"
        "它们集中在特定的城市与时段，具有可解释的成因。上方预警给出的具体时间点，"
        "正是防灾与生产调度真正需要的输入：知道哪一天、哪座城市、哪个时刻最需要提前响应。",
    )

with tab6:
    theme.scene_header("伍", "日用", "从数据回到生活")
    theme.lede(
        "分析的落点应当是具体的生活决策。本部分将前文的统计结论转化为旅游、出行与"
        "户外作业三类可执行的建议。"
    )
    travel_df = filtered.groupby("city").agg({
        "temp": "mean", "humidity": "mean", "wind": "mean", "comfort_score": "mean"
    }).reset_index().sort_values("comfort_score", ascending=False)
    travel_df["推荐理由"] = travel_df.apply(
        lambda r: f"舒适评分{r['comfort_score']:.1f}分，气温{r['temp']:.1f}°C，适宜旅游", axis=1
    )
    fig_travel = px.bar(
        travel_df.head(8), x="comfort_score", y="city", orientation="h", color="comfort_score",
        color_continuous_scale=SCALE_SCORE, labels={"comfort_score": "旅游舒适评分", "city": "地市"},
        height=CHART_M,
    )
    fig_travel.update_yaxes(categoryorder="total ascending")
    st.subheader("旅游舒适度排名")
    st.plotly_chart(theme.polish(fig_travel), use_container_width=True, config=PLOT_CFG)
    st.markdown("#### 推荐城市")
    for _, row in travel_df.head(3).iterrows():
        st.markdown(
            f"<div class='success-box'><b>{row['city']}</b>：{row['推荐理由']}，湿度{row['humidity']:.1f}%，风速{row['wind']:.2f} m/s</div>",
            unsafe_allow_html=True,
        )

    st.subheader("出行建议")
    travel_city = st.selectbox("选择出行城市", selected_cities)
    available_dates = sorted(filtered[filtered["city"] == travel_city]["date"].unique())
    if available_dates:
        default_date = available_dates[0]
        travel_date = st.date_input(
            "选择出行日期",
            value=default_date,
            min_value=min(available_dates),
            max_value=max(available_dates),
        )
        travel_records = filtered[
            (filtered["city"] == travel_city) & (filtered["date"] == travel_date)
        ]
        if not travel_records.empty:
            avg_rec = travel_records.iloc[0]
            advice = get_weather_advice(avg_rec["temp"], avg_rec["wind"], avg_rec["humidity"])
            cols = st.columns(3)
            cols[0].metric("温度", f"{avg_rec['temp']:.2f}°C")
            cols[1].metric("风速", f"{avg_rec['wind']:.2f}m/s")
            cols[2].metric("湿度", f"{avg_rec['humidity']:.2f}%")
            for a in advice:
                st.markdown(f"<div class='insight-box'>{a}</div>", unsafe_allow_html=True)
        else:
            st.info("所选日期无数据，请调整日期。")
    else:
        st.info("当前筛选条件下无可用日期，请调整月份范围。")

    st.subheader("户外作业适宜性评估")
    work_city = st.selectbox("选择作业城市", selected_cities, key="work_city")
    work_df = filtered[filtered["city"] == work_city].groupby("date").agg({
        "temp": "mean", "wind": "mean", "humidity": "mean", "work_index": "mean"
    }).reset_index().sort_values("work_index", ascending=False)
    fig_work = px.line(
        work_df, x="date", y="work_index",
        labels={"date": "日期", "work_index": "作业适宜指数"},
        template="qilu", height=CHART_M,
    )
    fig_work.add_hline(y=80, line_dash="dot", line_color=PALETTE["spring"], annotation_text="非常适宜")
    fig_work.add_hline(y=60, line_dash="dot", line_color=PALETTE["autumn"], annotation_text="基本适宜")
    fig_work.add_hline(y=40, line_dash="dot", line_color=PALETTE["danger"], annotation_text="不适宜")
    st.plotly_chart(theme.polish(fig_work), use_container_width=True, config=PLOT_CFG)
    best_work_day = work_df.iloc[0]
    st.markdown(
        f"<div class='success-box'><b>{work_city}</b> 户外作业最佳日期：{best_work_day['date']}，"
        f"作业适宜指数 {best_work_day['work_index']:.2f}分，{get_work_suggestion(best_work_day['work_index'])}</div>",
        unsafe_allow_html=True,
    )

    st.subheader("城市对比")
    city_a = st.selectbox("选择城市 A", selected_cities, index=0)
    city_b = st.selectbox("选择城市 B", selected_cities, index=min(1, len(selected_cities)-1))
    if city_a != city_b:
        compare_df = filtered[filtered["city"].isin([city_a, city_b])].groupby("city").agg({
            "temp": "mean", "wind": "mean", "humidity": "mean",
            "comfort_score": "mean", "work_index": "mean"
        }).reset_index()
        fig_compare = go.Figure()
        for _, row in compare_df.iterrows():
            values = [row["temp"]/35*100, row["wind"]/10*100, row["humidity"], row["comfort_score"], row["work_index"]]
            fig_compare.add_trace(go.Scatterpolar(
                r=values + [values[0]], theta=radar_labels + [radar_labels[0]],
                fill="toself", name=row["city"], opacity=0.6,
            ))
        fig_compare.update_layout(
            polar=dict(radialaxis=dict(visible=True, range=[0, 100])),
            template="qilu", height=CHART_L,
        )
        st.plotly_chart(theme.polish(fig_compare), use_container_width=True, config=PLOT_CFG)
        better_city = compare_df.loc[compare_df["comfort_score"].idxmax(), "city"]
        st.markdown(
            f"<div class='insight-box'><b>城市对比结论：</b>从综合舒适度看，<b>{better_city}</b> 更适合居住、旅游与户外作业。</div>",
            unsafe_allow_html=True,
        )

    theme.closing(
        "本幕小结",
        "这一幕把前四幕的统计结论落到了可执行的层面。旅游推荐给出的是「按舒适度排序的候选清单」，"
        "出行建议精确到「某城某日的逐时条件」，作业适宜指数则用阈值线把「能不能干活」变成"
        "可判读的分数。三步共用同一套指标口径，因此结论之间彼此自洽，可以直接用于安排行程与工期。",
    )

with tab7:
    theme.scene_header("陆", "建模", "方法附录")
    theme.lede(
        "作为方法附录，本部分给出综合评价、气候分区、趋势拟合与显著性检验的具体实现与参数，"
        "供复核与复现。"
    )
    st.caption(
        "本模块提供建模分析方法：综合评价（熵权法 + TOPSIS）、城市气候分区（K-means）、"
        "趋势预测（最小二乘）、差异显著性检验（t 检验 / Mann-Whitney U）。"
        "所有指标、权重与检验结果均由当前筛选数据自动计算。"
    )

    city_agg = filtered.groupby("city").agg({
        "temp": "mean", "wind": "mean", "humidity": "mean",
        "comfort_score": "mean", "work_index": "mean",
    })
    n_model_cities = len(city_agg)

    st.markdown("### ① 综合评价模型：熵权法 + TOPSIS")
    st.markdown(
        "**建模思路**：先构建宜居宜游评价指标体系，用熵权法（客观赋权）确定各指标权重，"
        "再用 TOPSIS 计算各城市与理想解的贴近度，得到综合排名。"
    )

    w_df = None
    result_df = None
    if n_model_cities < 2:
        st.info("综合评价（熵权法 + TOPSIS）至少需要选择 2 个地市，请在左侧扩大地市选择范围。")
    else:
        eval_df = pd.DataFrame({
            "温度适宜度": 1.0 / (1.0 + (city_agg["temp"] - 22.5).abs()),
            "湿度适宜度": 1.0 / (1.0 + (city_agg["humidity"] - 55.0).abs()),
            "舒适评分": city_agg["comfort_score"],
            "作业适宜指数": city_agg["work_index"],
            "平均风速": city_agg["wind"],
        })
        indicator_names = list(eval_df.columns)
        # 5 个指标中前 4 个为效益型，平均风速为成本型（越小越好）
        benefit_mask = [True, True, True, True, False]

        st.dataframe(pd.DataFrame({
            "指标": indicator_names,
            "指标类型": ["效益型（越大越好）", "效益型（越大越好）", "效益型（越大越好）", "效益型（越大越好）", "成本型（越小越好）"],
            "均值": [f"{eval_df[c].mean():.4f}" for c in indicator_names],
            "标准差": [f"{eval_df[c].std():.4f}" for c in indicator_names],
        }), use_container_width=True, hide_index=True)

        weights, w_detail = entropy_weight(eval_df.values)
        closeness, t_detail = topsis(eval_df.values, weights, benefit_mask)

        result_df = pd.DataFrame({
            "城市": list(eval_df.index),
            "相对贴近度": np.round(closeness, 4),
        }).sort_values("相对贴近度", ascending=False).reset_index(drop=True)
        result_df.insert(0, "排名", range(1, len(result_df) + 1))
        result_df["评价等级"] = pd.cut(
            result_df["相对贴近度"],
            bins=[-0.001, 0.35, 0.55, 0.75, 1.001],
            labels=["一般", "中等", "良好", "优秀"],
        ).astype(str)

        col_w, col_r = st.columns([2, 3])
        with col_w:
            w_df = pd.DataFrame({
                "指标": indicator_names,
                "信息熵 e": np.round(w_detail["entropy"], 4),
                "差异系数 d": np.round(w_detail["diff_coef"], 4),
                "权重 w": np.round(weights, 4),
            }).sort_values("权重 w", ascending=False).reset_index(drop=True)
            st.markdown("**熵权法权重计算结果**")
            st.dataframe(w_df, use_container_width=True, hide_index=True)
        with col_r:
            fig_w = px.bar(
                w_df, x="权重 w", y="指标", orientation="h", color="权重 w",
                color_continuous_scale=SCALE_WIND, text="权重 w",
                height=CHART_S,
            )
            fig_w.update_yaxes(categoryorder="total ascending")
            fig_w.update_traces(texttemplate="%{text:.4f}", textposition="outside")
            fig_w.update_layout(showlegend=False, coloraxis_showscale=False)
            st.subheader("指标权重（熵权法）")
            st.plotly_chart(theme.polish(fig_w), use_container_width=True, config=PLOT_CFG)

        st.markdown("**TOPSIS 综合评价结果**")
        fig_rank = px.bar(
            result_df, x="相对贴近度", y="城市", orientation="h", color="相对贴近度",
            color_continuous_scale=SCALE_SCORE, text="相对贴近度",
            height=CHART_M,
        )
        fig_rank.update_yaxes(categoryorder="total ascending")
        fig_rank.update_traces(texttemplate="%{text:.4f}", textposition="outside")
        fig_rank.update_layout(coloraxis_showscale=False)
        st.subheader("综合评价贴近度排名")
        st.plotly_chart(theme.polish(fig_rank), use_container_width=True, config=PLOT_CFG)
        st.dataframe(result_df, use_container_width=True, hide_index=True)

        if n_model_cities >= 2:
            st.markdown(
                f"<div class='insight-box'><b>综合评价结论：</b>综合排名第 1 的是 <b>{result_df.iloc[0]['城市']}</b>"
                f"（贴近度 {result_df.iloc[0]['相对贴近度']:.4f}，等级「{result_df.iloc[0]['评价等级']}」），"
                f"末位是 <b>{result_df.iloc[-1]['城市']}</b>（贴近度 {result_df.iloc[-1]['相对贴近度']:.4f}）。"
                f"权重最大的指标是 <b>{w_df.iloc[0]['指标']}</b>（{w_df.iloc[0]['权重 w']:.4f}），"
                f"说明该指标在本次筛选数据中区分度最高、对评价结果影响最大。</div>",
                unsafe_allow_html=True,
            )

    st.markdown("---")

    st.markdown("### ② 城市气候分区：K-means 聚类")
    st.markdown(
        "**建模思路**：选取温度、湿度、风速、舒适评分 4 个维度，标准化后做 K-means 聚类，"
        "用**轮廓系数**自动确定最优聚类数 K，从而将城市划分为若干气候类型区。"
    )

    best_k = None
    sil_scores = {}
    profile = None
    if n_model_cities < 3:
        st.info("聚类分析至少需要 3 个城市，请扩大地市选择范围。")
    else:
        cluster_feats = ["temp", "humidity", "wind", "comfort_score"]
        X_cluster = city_agg[cluster_feats].values
        try:
            best_k, labels, sil_scores, X_scaled = kmeans_cluster(X_cluster, k_range=(2, 7))
            cluster_df = pd.DataFrame({
                "城市": list(city_agg.index),
                "气候类型": [f"类型 {int(l) + 1}" for l in labels],
                "温度": np.round(city_agg["temp"].values, 2),
                "湿度": np.round(city_agg["humidity"].values, 2),
                "风速": np.round(city_agg["wind"].values, 2),
                "舒适评分": np.round(city_agg["comfort_score"].values, 2),
            })

            col_s, col_p = st.columns([2, 3])
            with col_s:
                sil_df = pd.DataFrame({
                    "聚类数 K": list(sil_scores.keys()),
                    "轮廓系数": [round(v, 4) for v in sil_scores.values()],
                })
                fig_sil = px.line(
                    sil_df, x="聚类数 K", y="轮廓系数", markers=True,
                    height=CHART_S,
                    template="qilu",
                )
                fig_sil.add_vline(x=best_k, line_dash="dash", line_color=PALETTE["sun"],
                                  annotation_text=f"最优 K={best_k}")
                fig_sil.update_xaxes(dtick=1)
                st.subheader("轮廓系数法确定最优 K")
                st.plotly_chart(theme.polish(fig_sil), use_container_width=True, config=PLOT_CFG)
                st.markdown(
                    f"<div class='insight-box'><b>最优聚类数：K = {best_k}</b>"
                    f"（轮廓系数 {sil_scores[best_k]:.4f}，越接近 1 说明类内越紧密、类间越分离）。</div>",
                    unsafe_allow_html=True,
                )
            with col_p:
                fig_cluster = px.scatter(
                    cluster_df, x="温度", y="湿度", color="气候类型",
                    text="城市", size="舒适评分",
                    height=CHART_M, template="qilu",
                )
                fig_cluster.update_traces(textposition="top center", marker=dict(sizemin=8))
                st.subheader("城市气候聚类结果")
                st.plotly_chart(theme.polish(fig_cluster), use_container_width=True, config=PLOT_CFG)

            st.markdown("**各类气候类型特征画像**")
            profile = cluster_df.groupby("气候类型").agg({
                "温度": "mean", "湿度": "mean", "风速": "mean", "舒适评分": "mean",
            }).round(2)
            profile["城市数"] = cluster_df.groupby("气候类型").size()
            profile["包含城市"] = cluster_df.groupby("气候类型")["城市"].apply(lambda s: "、".join(s))
            st.dataframe(profile.reset_index(), use_container_width=True, hide_index=True)

            st.markdown("**城市气候分区归属**")
            st.dataframe(cluster_df.sort_values(["气候类型", "城市"]), use_container_width=True, hide_index=True)

            profile_reset = profile.reset_index()
            best_type = profile_reset.loc[profile_reset["舒适评分"].idxmax(), "气候类型"]
            best_cities = profile_reset.loc[profile_reset["舒适评分"].idxmax(), "包含城市"]
            st.markdown(
                f"<div class='insight-box'><b>聚类结论：</b>最优聚类数为 <b>K = {best_k}</b>，"
                f"即将选中城市划分为 <b>{best_k}</b> 个气候类型区。"
                f"其中 <b>{best_type}</b> 的综合舒适评分最高（{profile_reset['舒适评分'].max():.2f}），"
                f"包含 {best_cities}，气候条件相对最优。"
                f"聚类结果为差异化政策制定提供了依据：不同气候类型区宜采取不同的旅游推广与作业安排策略。</div>",
                unsafe_allow_html=True,
            )
        except ValueError as e:
            st.warning(f"聚类失败：{e}")

    st.markdown("---")

    st.markdown("### ③ 趋势预测：最小二乘线性拟合")
    st.markdown(
        "**建模思路**：对月度均值序列建立一元线性回归模型 `y = a·x + b`，"
        "用判定系数 R² 衡量线性趋势强度，并向后外推预测未来 3 期。"
    )

    monthly_series = filtered.groupby("month")[metric].mean().sort_index()
    if len(monthly_series) < 3:
        st.info("趋势预测至少需要 3 个月的数据，请扩大月份范围。")
    else:
        fc = linear_trend_forecast(monthly_series.values, periods=3)
        last_month = int(monthly_series.index[-1])
        future_months = []
        m = last_month
        for _ in range(3):
            m = m + 1 if m < 12 else 1
            future_months.append(f"{m}月")

        trend_df = pd.DataFrame({
            "月份": [f"{int(i)}月" for i in monthly_series.index] + future_months,
            "数值": np.round(fc["fitted"], 3).tolist() + [None] * 3,
            "实际值": np.round(monthly_series.values, 3).tolist() + [None] * 3,
            "预测值": [None] * len(monthly_series) + np.round(fc["forecast"], 3).tolist(),
            "类型": ["历史拟合"] * len(monthly_series) + ["预测"] * 3,
        })

        fig_trend = go.Figure()
        fig_trend.add_trace(go.Scatter(
            x=trend_df["月份"], y=trend_df["实际值"], mode="markers+lines",
            name="实际值", marker=dict(size=8),
        ))
        fig_trend.add_trace(go.Scatter(
            x=trend_df["月份"], y=trend_df["数值"], mode="lines",
            name="线性拟合", line=dict(dash="dash", color=PALETTE["sun"], width=2),
        ))
        fig_trend.add_trace(go.Scatter(
            x=trend_df["月份"], y=trend_df["预测值"], mode="markers+lines",
            name="未来预测", line=dict(color=PALETTE["danger"], width=2), marker=dict(size=11, symbol="diamond"),
        ))
        fig_trend.update_layout(
            template="qilu", height=CHART_M,
            xaxis_title="月份", yaxis_title=metric_label,
        )
        st.subheader("月度趋势拟合与预测")
        st.plotly_chart(theme.polish(fig_trend), use_container_width=True, config=PLOT_CFG)

        c_t1, c_t2, c_t3, c_t4 = st.columns(4)
        c_t1.metric("回归斜率 a", f"{fc['slope']:.4f}")
        c_t2.metric("判定系数 R²", f"{fc['r2']:.4f}")
        c_t3.metric("显著性 p 值", f"{fc['p_value']:.4f}")
        c_t4.metric("趋势方向", "上升" if fc["slope"] > 0 else "下降")

        trend_strength = "很强" if fc["r2"] > 0.8 else ("较强" if fc["r2"] > 0.5 else ("较弱" if fc["r2"] > 0.2 else "很弱"))
        sig_txt = "具有统计显著性" if fc["p_value"] < 0.05 else "未达到统计显著性"
        st.markdown(
            f"<div class='insight-box'><b>趋势预测结论：</b>{metric_label}的线性趋势斜率为 "
            f"<b>{fc['slope']:.4f}</b>（每期变化量），R² = <b>{fc['r2']:.4f}</b>，说明线性趋势拟合程度「{trend_strength}」，"
            f"且{sig_txt}（p = {fc['p_value']:.4f}）。"
            f"未来 3 期预测值依次为 "
            f"{'、'.join([f'{v:.2f}' for v in fc['forecast']])}。"
            f"{'R² 偏低，说明该指标受季节周期影响大于线性趋势，纯线性外推仅作参考。' if fc['r2'] < 0.5 else '线性趋势可较好地解释该指标变化。'}</div>",
            unsafe_allow_html=True,
        )

    st.markdown("---")

    st.markdown("### ④ 差异显著性检验：沿海 vs 内陆")
    st.markdown(
        "**建模思路**：先对两组数据做 Shapiro-Wilk 正态性检验；"
        "若两组均近似正态，则做 Levene 方差齐性检验后选择独立样本 t 检验；"
        "否则自动改用 Mann-Whitney U 非参数检验。"
    )

    coastal_data = filtered[filtered["city"].isin(COASTAL)]
    inland_data = filtered[filtered["city"].isin([c for c in CITIES if c not in COASTAL])]

    if coastal_data.empty or inland_data.empty:
        st.info("差异检验需要同时包含沿海与内陆城市，请调整地市选择。")
    else:
        test_metrics = [("temp", "温度"), ("humidity", "湿度"), ("wind", "风速"), ("comfort_score", "舒适评分")]
        rows = []
        for col, name in test_metrics:
            r = compare_groups(coastal_data[col].values, inland_data[col].values)
            rows.append({
                "指标": name,
                "沿海均值": round(r["mean_a"], 2),
                "内陆均值": round(r["mean_b"], 2),
                "均值差": round(r["mean_a"] - r["mean_b"], 2),
                "检验方法": r["test"],
                "统计量": round(r["stat"], 3) if not np.isnan(r["stat"]) else "-",
                "p 值": f"{r['p_value']:.4f}" if not np.isnan(r["p_value"]) else "-",
                "显著性": significance_mark(r["p_value"]),
                "结论": "差异显著" if r.get("significant") else "差异不显著",
            })
        test_df = pd.DataFrame(rows)
        st.dataframe(test_df, use_container_width=True, hide_index=True)
        st.caption("显著性标记：*** p<0.001，** p<0.01，* p<0.05，n.s. 不显著")

        fig_box_cmp = px.box(
            filtered.assign(区域=filtered["city"].apply(classify_region)),
            x="区域", y=metric, color="区域", points="outliers",
            height=CHART_M,
            template="qilu",
        )
        st.subheader("沿海与内陆分布对比")
        st.plotly_chart(theme.polish(fig_box_cmp), use_container_width=True, config=PLOT_CFG)

        sig_items = test_df[test_df["结论"] == "差异显著"]["指标"].tolist()
        if sig_items:
            st.markdown(
                f"<div class='insight-box'><b>检验结论：</b>在 0.05 显著性水平下，"
                f"<b>{'、'.join(sig_items)}</b> 在沿海与内陆之间存在统计学上的显著差异；"
                f"其余指标差异不显著，说明其分布可能主要由其他因素决定。"
                f"该结论为「沿海城市受海洋调节」提供了统计依据，而非仅凭图表观察。</div>",
                unsafe_allow_html=True,
            )
        else:
            st.markdown(
                "<div class='insight-box'><b>检验结论：</b>在 0.05 显著性水平下，"
                "所选指标在沿海与内陆之间均未表现出显著差异，说明两地气候特征在该筛选条件下较为接近。</div>",
                unsafe_allow_html=True,
            )

    st.markdown("---")

    st.markdown("### ⑤ 建模分析报告导出")

    def build_model_report():
        L = []
        L.append(f"# {metric_label} 建模分析报告\n")
        L.append(f"**数据范围**：{filtered['dt'].min():%Y-%m-%d} ~ {filtered['dt'].max():%Y-%m-%d}，"
                 f"共 {len(filtered):,} 条记录，覆盖 {n_model_cities} 个地市。\n")

        L.append("## 一、综合评价模型（熵权法 + TOPSIS）\n")
        if w_df is not None and result_df is not None:
            L.append("### 1.1 指标权重（熵权法）\n")
            L.append("| 指标 | 信息熵 e | 差异系数 d | 权重 w |")
            L.append("|---|---|---|---|")
            for _, r in w_df.iterrows():
                L.append(f"| {r['指标']} | {r['信息熵 e']:.4f} | {r['差异系数 d']:.4f} | {r['权重 w']:.4f} |")
            L.append("\n### 1.2 综合排名（TOPSIS）\n")
            L.append("| 排名 | 城市 | 相对贴近度 | 评价等级 |")
            L.append("|---|---|---|---|")
            for _, r in result_df.iterrows():
                L.append(f"| {r['排名']} | {r['城市']} | {r['相对贴近度']:.4f} | {r['评价等级']} |")
        else:
            L.append("*所选地市不足 2 个，未生成综合评价结果。*")

        if n_model_cities >= 3 and best_k is not None:
            L.append("\n## 二、城市气候分区（K-means 聚类）\n")
            L.append(f"最优聚类数 **K = {best_k}**（轮廓系数 {sil_scores[best_k]:.4f}）。\n")
            L.append("| 气候类型 | 温度 | 湿度 | 风速 | 舒适评分 | 城市数 | 包含城市 |")
            L.append("|---|---|---|---|---|---|---|")
            for _, r in profile.reset_index().iterrows():
                L.append(f"| {r['气候类型']} | {r['温度']:.2f} | {r['湿度']:.2f} | {r['风速']:.2f} | "
                         f"{r['舒适评分']:.2f} | {r['城市数']} | {r['包含城市']} |")

        if len(monthly_series) >= 3:
            L.append("\n## 三、趋势预测（最小二乘线性拟合）\n")
            L.append(f"- 回归方程：y = {fc['slope']:.4f}·x + {fc['intercept']:.4f}")
            L.append(f"- 判定系数 R² = {fc['r2']:.4f}")
            L.append(f"- 显著性 p 值 = {fc['p_value']:.4f}")
            L.append(f"- 未来 3 期预测值：{'、'.join([f'{v:.2f}' for v in fc['forecast']])}")

        if not coastal_data.empty and not inland_data.empty:
            L.append("\n## 四、差异显著性检验（沿海 vs 内陆）\n")
            L.append("| 指标 | 沿海均值 | 内陆均值 | 检验方法 | p 值 | 显著性 |")
            L.append("|---|---|---|---|---|---|")
            for _, r in test_df.iterrows():
                L.append(f"| {r['指标']} | {r['沿海均值']} | {r['内陆均值']} | {r['检验方法']} | "
                         f"{r['p 值']} | {r['显著性']} |")
            L.append("\n> 显著性标记：*** p<0.001，** p<0.01，* p<0.05，n.s. 不显著")

        L.append("\n---\n*报告由山东天气数据可视化平台自动生成*")
        return "\n".join(L)

    try:
        model_report = build_model_report()
        st.download_button(
            "下载建模分析报告（Markdown）",
            data=model_report.encode("utf-8"),
            file_name="建模分析报告.md",
            mime="text/markdown",
        )
        with st.expander("预览报告内容"):
            st.markdown(model_report)
    except Exception as e:  # noqa: BLE001
        st.warning(f"报告生成失败：{e}")

    theme.closing(
        "本幕小结",
        "本幕是方法附录，四类模型各自回答一个问题：熵权法＋TOPSIS 回答「综合怎么排」，"
        "K-means 回答「能不能分成几类」，最小二乘回答「趋势朝哪走」，显著性检验回答"
        "「差异是不是真的」。所有参数随左侧筛选条件实时重算，不含任何人工指定的权重，"
        "因而结论可被逐步复核与复现。",
    )

with tab8:
    theme.scene_header("附", "数据", "下载与导出")
    theme.lede("提供当前筛选条件下的原始记录预览与导出，便于独立核验。")
    display_cols = ["city", "dt", "temp", "wind", "humidity", "thi", "wci", "comfort_score", "work_index"]
    st.dataframe(filtered[display_cols].rename(columns={
        "city": "地市", "dt": "时间", "temp": "温度", "wind": "最大风速",
        "humidity": "相对湿度", "thi": "舒适度指数", "wci": "风冷指数",
        "comfort_score": "舒适评分", "work_index": "作业适宜指数",
    }), use_container_width=True, height=380)

    csv_bytes = filtered[display_cols].to_csv(index=False, encoding="utf-8-sig").encode("utf-8-sig")
    b64 = base64.b64encode(csv_bytes).decode()
    href = f"""
        <a href="data:file/csv;base64,{b64}" download="filtered_weather_data.csv"
           class="ql-dl">下载筛选后数据（CSV）</a>
    """
    st.markdown(href, unsafe_allow_html=True)

    st.subheader("城市聚合统计表")
    summary = filtered.groupby("city").agg({
        "temp": ["mean", "min", "max"],
        "wind": ["mean", "max"],
        "humidity": ["mean", "min", "max"],
        "comfort_score": "mean", "work_index": "mean",
    }).round(2)
    summary.columns = ["_".join(c) for c in summary.columns]
    st.dataframe(summary.reset_index().rename(columns={"city": "地市"}), use_container_width=True)

# 尾章不设分隔线，靠底色块与各幕正文区分
theme.closing(
    "结语",
    "温度、湿度与风，构成了一方水土最基础的物理背景。它们在一日之内起伏，在一年之间轮回，"
    "在山海之间分野，也在极值时刻提醒人们保持敬畏。<br>"
    "八幕走完，这套图谱所做的，是把 17,520 条离散的观测记录，还原成可以被阅读的节律与秩序——"
    "让数据不只是数字，而是关于这片土地如何呼吸的一份记录。",
)
theme.footer(
    "一日 · 四季 &nbsp;|&nbsp; 山东省气象数据可视化 &nbsp;|&nbsp; "
    "数据来源：山东省各地市气象观测站 2025 年逐日观测"
)
