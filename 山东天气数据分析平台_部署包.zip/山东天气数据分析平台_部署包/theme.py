# -*- coding: utf-8 -*-
"""视觉设计系统：色彩、字体、全局 CSS、Plotly 模板与页面组件。"""

import plotly.graph_objects as go
import plotly.io as pio
import streamlit as st

PALETTE = {
    "ink":       "#1C2B33",
    "ink_soft":  "#48606B",
    "muted":     "#8B9AA3",
    "line":      "#E4E0D7",
    "paper":     "#FBFAF7",
    "card":      "#FFFFFF",

    "sea":       "#1B4B5A",
    "sea_mid":   "#2D7A8C",
    "sea_soft":  "#A8CBD4",
    "sea_wash":  "#EAF2F4",

    "sun":       "#E8794A",
    "sun_soft":  "#F7C9B2",
    "sun_wash":  "#FDF0E9",

    "spring":    "#7FA65C",
    "summer":    "#E8794A",
    "autumn":    "#C99A3E",
    "winter":    "#5B8CA8",

    "warn":      "#C99A3E",
    "danger":    "#B33A1F",
}

CATEGORICAL = [
    "#1B4B5A", "#E8794A", "#7FA65C", "#C99A3E",
    "#5B8CA8", "#9B6B9E", "#0F6E56", "#A63D40",
]

SCALE_TEMP = [
    [0.00, "#2C5F8A"], [0.25, "#6FA8C7"], [0.50, "#EDE4D3"],
    [0.75, "#E8A05C"], [1.00, "#B33A1F"],
]
SCALE_HUMID = [
    [0.00, "#E8DFC8"], [0.50, "#8FBFC4"], [1.00, "#1B4B5A"],
]
SCALE_WIND = [
    [0.00, "#EAF2F4"], [0.50, "#7FA8B8"], [1.00, "#2D5A6B"],
]
SCALE_DIV = [
    [0.00, "#2C5F8A"], [0.50, "#FBFAF7"], [1.00, "#B33A1F"],
]
SCALE_SCORE = [
    [0.00, "#B33A1F"], [0.35, "#E8A05C"], [0.65, "#A8C48A"], [1.00, "#3E7C4A"],
]

METRIC_SCALE = {
    "temp": SCALE_TEMP, "humidity": SCALE_HUMID, "wind": SCALE_WIND,
    "thi": SCALE_SCORE, "wci": SCALE_SCORE,
    "comfort_score": SCALE_SCORE, "work_index": SCALE_SCORE,
}

FONT_SERIF = '"Source Han Serif SC", "Noto Serif SC", "Songti SC", SimSun, "STSong", serif'
FONT_SANS = '"Source Han Sans SC", "Noto Sans SC", "PingFang SC", "Microsoft YaHei", "Hiragino Sans GB", sans-serif'
FONT_MONO = '"JetBrains Mono", Consolas, "Courier New", monospace'

# 图表高度三级：S=360 辅助图 / M=440 常规图 / L=520 重量图
CHART_S = 360
CHART_M = 440
CHART_L = 520


def polish(fig, height=None):
    """统一收尾处理，供所有图表调用。"""
    # 清空图例标题：Plotly 自动取的字段名会与图表标题横向重叠
    fig.update_layout(legend_title_text="")
    if height is not None:
        fig.update_layout(height=height)
    return fig


def inject_css():
    """注入全局样式，覆盖 Streamlit 默认外观"""
    st.markdown(
        f"""
<style>
:root {{
  --ink: {PALETTE['ink']};
  --ink-soft: {PALETTE['ink_soft']};
  --muted: {PALETTE['muted']};
  --line: {PALETTE['line']};
  --paper: {PALETTE['paper']};
  --card: {PALETTE['card']};
  --sea: {PALETTE['sea']};
  --sea-mid: {PALETTE['sea_mid']};
  --sea-soft: {PALETTE['sea_soft']};
  --sea-wash: {PALETTE['sea_wash']};
  --sun: {PALETTE['sun']};
  --sun-wash: {PALETTE['sun_wash']};
  --serif: {FONT_SERIF};
  --sans: {FONT_SANS};
}}

.stApp {{ background: var(--paper); }}
[data-testid="stHeader"] {{ background: transparent; height: 0; }}
[data-testid="stToolbar"] {{ right: 12px; }}
/* 主内容滚动容器：1.32 为 section.main，1.56 为 [data-testid="stMain"] */
[data-testid="stAppViewContainer"] > .main,
section.main,
[data-testid="stMain"] {{ padding-top: 0; }}
.block-container {{ padding: 0 3.4rem 4.5rem 3.4rem; max-width: 1320px; }}

html, body, [class*="css"] {{ font-family: var(--sans); }}
h1, h2, h3, h4 {{
  font-family: var(--serif) !important;
  color: var(--ink) !important;
  font-weight: 500 !important;
  line-height: 1.45 !important;
  letter-spacing: .01em;
}}
h2 {{
  font-size: 1.62rem !important;
  margin-top: 3.4rem !important;
  margin-bottom: 1.1rem !important;
  padding-bottom: .55rem !important;
  border-bottom: 1px solid var(--line) !important;
}}
h3 {{
  font-size: 1.14rem !important;
  margin-top: 2.9rem !important;
  margin-bottom: 1.6rem !important;
  padding-left: 13px !important;
  border-left: 3px solid var(--sun);
  line-height: 1.4 !important;
}}
[data-testid="stSidebar"] h3 {{ border-left: none; padding-left: 0 !important; }}
p, li, span, div {{ color: var(--ink); }}
hr {{ border: none; border-top: 1px solid var(--line); margin: 2.4rem 0; }}

[data-testid="stMarkdownContainer"] p {{ font-size: 15px; line-height: 1.85; }}
[data-testid="stMarkdownContainer"] li {{ font-size: 14.5px; line-height: 1.85; }}
[data-testid="stCaptionContainer"] p {{ font-size: 12.5px; }}

section.main [data-testid="stMarkdownContainer"] > p,
[data-testid="stMain"] [data-testid="stMarkdownContainer"] > p {{ max-width: 900px; }}
section.main [data-testid="stMarkdownContainer"] > ul,
section.main [data-testid="stMarkdownContainer"] > ol,
[data-testid="stMain"] [data-testid="stMarkdownContainer"] > ul,
[data-testid="stMain"] [data-testid="stMarkdownContainer"] > ol {{ max-width: 900px; }}
.ql-card [data-testid="stMarkdownContainer"] p,
.ql-card p {{ max-width: none; }}

[data-testid="stSidebar"] {{
  background: #F4F2ED;
  border-right: 1px solid var(--line);
  min-width: 340px !important;
  max-width: 340px !important;
  width: 340px !important;
}}
[data-testid="stSidebar"] > div:first-child {{ width: 340px !important; }}
/* 侧边栏通配符须排除图标元素，理由见文末「图标字体保护」 */
[data-testid="stSidebar"] *:not([data-testid="stIconMaterial"]) {{ font-family: var(--sans); }}
[data-testid="stSidebar"] h2,
[data-testid="stSidebar"] h3 {{
  font-family: var(--serif) !important;
  font-size: 1.02rem !important;
  line-height: 1.5 !important;
  letter-spacing: .12em;
  color: var(--sea) !important;
  margin: 0 0 .55rem 0 !important;
}}

[data-testid="stSidebar"] [data-testid="stWidgetLabel"] p,
[data-testid="stSidebar"] [data-testid="stWidgetLabel"] label,
[data-testid="stSidebar"] > div > div > div > label {{
  font-size: 13px !important;
  line-height: 1.5 !important;
  color: var(--ink-soft) !important;
  margin-bottom: 2px !important;
}}

[data-testid="stSidebar"] [data-testid="stMarkdownContainer"] p,
[data-testid="stSidebar"] [data-testid="stCaptionContainer"] p {{
  font-size: 13px !important;
  line-height: 1.68 !important;
}}
[data-testid="stSidebar"] [data-testid="stMarkdownContainer"] li {{
  font-size: 13px !important;
  line-height: 1.68 !important;
}}
[data-testid="stSidebar"] [data-testid="stMarkdownContainer"] strong {{ font-weight: 600; }}

[data-testid="stSidebar"] [data-baseweb="radio"] div,
[data-testid="stSidebar"] [data-baseweb="radio"] label,
[data-testid="stSidebar"] [data-baseweb="checkbox"] div,
[data-testid="stSidebar"] [data-baseweb="select"] div,
[data-testid="stSidebar"] [data-baseweb="select"] span,
[data-testid="stSidebar"] [data-baseweb="tag"] span {{
  font-size: 13.5px !important;
  line-height: 1.5 !important;
}}
[data-testid="stSidebar"] [data-testid="stAlert"] p,
[data-testid="stSidebar"] [data-testid="stAlert"] span,
[data-testid="stSidebar"] [data-testid="stAlert"] div {{
  font-size: 12.5px !important;
  line-height: 1.72 !important;
}}
[data-testid="stSidebar"] [data-testid="stSlider"] div {{ font-size: 12.5px !important; }}
[data-testid="stSidebar"] [data-testid="stExpander"] summary,
[data-testid="stSidebar"] [data-testid="stExpander"] summary p {{
  font-size: 13px !important;
  line-height: 1.5 !important;
}}

.stTabs [data-baseweb="tab-list"] {{
  gap: 2px;
  border-bottom: 1px solid var(--line);
  padding: 0;
  margin-bottom: 1.6rem;
}}
.stTabs [data-baseweb="tab"] {{
  height: auto;
  padding: 12px 18px 13px 18px;
  background: transparent;
  border-radius: 0;
  border-bottom: 2px solid transparent;
  font-family: var(--sans);
  font-size: 14.5px;
  font-weight: 400;
  color: var(--ink-soft);
  letter-spacing: .02em;
}}
.stTabs [data-baseweb="tab"]:hover {{ color: var(--sea); background: rgba(27,75,90,.04); }}
.stTabs [aria-selected="true"] {{
  color: var(--sea) !important;
  border-bottom: 2px solid var(--sun) !important;
  font-weight: 500 !important;
}}
.stTabs [data-baseweb="tab-highlight"], .stTabs [data-baseweb="tab-border"] {{ display: none; }}

[data-testid="stMetric"] {{
  background: var(--card);
  border: 1px solid var(--line);
  border-radius: 2px;
  padding: 16px 18px;
}}
[data-testid="stMetricLabel"] p {{
  font-size: 12.5px !important;
  line-height: 1.5 !important;
  color: var(--muted) !important;
  letter-spacing: .06em;
}}
[data-testid="stMetricValue"] {{
  font-family: var(--serif);
  font-size: 1.7rem !important;
  line-height: 1.35 !important;
  color: var(--sea) !important;
  font-weight: 500;
}}

[data-testid="stDataFrame"] {{ border: 1px solid var(--line); border-radius: 2px; }}
[data-testid="stDataFrame"] *:not([data-testid="stIconMaterial"]) {{ font-family: var(--sans) !important; font-size: 13px !important; line-height: 1.5 !important; }}
[data-testid="stDataFrame"] [role="columnheader"],
[data-testid="stDataFrame"] [role="columnheader"] * {{
  font-family: var(--serif) !important;
  font-size: 13px !important;
  color: var(--sea) !important;
  font-weight: 500 !important;
}}
[data-testid="stDataFrame"] [role="gridcell"],
[data-testid="stDataFrame"] [role="gridcell"] * {{
  font-size: 13px !important;
  color: var(--ink) !important;
}}

[data-testid="stExpander"] {{
  border: 1px solid var(--line) !important;
  border-radius: 2px !important;
  background: var(--card);
}}
[data-testid="stExpander"] summary {{
  font-family: var(--serif);
  color: var(--sea);
  font-size: 14.5px;
  line-height: 1.5;
}}

.stButton > button, .stDownloadButton > button {{
  background: var(--sea);
  color: #FFFFFF;
  border: none;
  border-radius: 2px;
  padding: 9px 20px;
  font-family: var(--sans);
  font-size: 13px;
  letter-spacing: .04em;
}}
.stButton > button:hover, .stDownloadButton > button:hover {{
  background: var(--sun); color: #FFFFFF;
}}

[data-testid="stAlert"] {{
  border-radius: 2px;
  border-left: 3px solid var(--sea-mid);
  background: var(--sea-wash);
}}
[data-testid="stAlert"] p {{ font-size: 13.5px; line-height: 1.75; }}

[data-testid="stFileUploader"] section {{
  border: 1px dashed var(--line);
  border-radius: 2px;
  background: var(--card);
}}

::-webkit-scrollbar {{ width: 9px; height: 9px; }}
::-webkit-scrollbar-track {{ background: transparent; }}
::-webkit-scrollbar-thumb {{ background: #D5D1C7; border-radius: 5px; }}
::-webkit-scrollbar-thumb:hover {{ background: var(--muted); }}

.ql-hero {{
  position: relative;
  margin: 0 -3.2rem 2.6rem -3.2rem;
  padding: 4.2rem 3.2rem 3.4rem 3.2rem;
  background: linear-gradient(160deg, #17414E 0%, #1B4B5A 55%, #245C6B 100%);
  overflow: hidden;
}}
.ql-hero::after {{
  content: "";
  position: absolute; right: -60px; top: -60px;
  width: 320px; height: 320px; border-radius: 50%;
  background: radial-gradient(circle, rgba(232,121,74,.30) 0%, rgba(232,121,74,0) 68%);
}}
.ql-hero-kicker {{
  font-family: var(--sans);
  font-size: 12px; letter-spacing: .34em;
  color: {PALETTE['sun_soft']};
  text-transform: uppercase;
  margin: 0 0 18px 0;
}}
.ql-hero-title {{
  font-family: var(--serif);
  font-size: 3.05rem; line-height: 1.18;
  color: #FFFFFF !important; margin: 0 0 16px 0;
  font-weight: 500; letter-spacing: .04em;
}}
.ql-hero-sub {{
  font-family: var(--sans);
  font-size: 15px; line-height: 1.85;
  color: rgba(255,255,255,.78);
  max-width: 640px; margin: 0 0 30px 0;
}}
.ql-hero-meta {{
  display: flex; flex-wrap: wrap; gap: 0;
  border-top: 1px solid rgba(255,255,255,.18);
  padding-top: 18px; margin-top: 4px;
}}
.ql-hero-meta div {{
  padding-right: 34px; margin-right: 34px;
  border-right: 1px solid rgba(255,255,255,.14);
}}
.ql-hero-meta div:last-child {{ border-right: none; }}
.ql-hero-meta .k {{
  display: block; font-size: 11px; letter-spacing: .16em;
  color: rgba(255,255,255,.52); margin-bottom: 5px;
}}
.ql-hero-meta .v {{
  display: block; font-family: var(--serif);
  font-size: 19px; color: #FFFFFF !important;
}}

.ql-scene {{
  display: flex; align-items: baseline; gap: 18px;
  margin: 0.6rem 0 0.4rem 0;
  padding-bottom: 14px;
  border-bottom: 1px solid var(--line);
}}
.ql-scene-no {{
  font-family: var(--serif);
  font-size: 2.2rem; line-height: 1.35;
  color: var(--sun); opacity: .88;
  min-width: 42px;
}}
.ql-scene-title {{
  font-family: var(--serif);
  font-size: 1.88rem; line-height: 1.35 !important;
  color: var(--sea) !important; margin: 0;
}}
.ql-scene-lede {{
  font-family: var(--sans);
  font-size: 13.5px; line-height: 1.6;
  color: var(--muted);
  margin: 6px 0 0 0; letter-spacing: .02em;
}}

.ql-lede {{
  font-family: var(--sans);
  font-size: 15px; line-height: 2.0;
  color: var(--ink-soft);
  max-width: 780px;
  margin: 1.6rem 0 2.2rem 0;
  padding-left: 16px;
  border-left: 2px solid var(--sea-soft);
}}

.ql-insight {{
  font-family: var(--sans);
  font-size: 15px; line-height: 1.95;
  color: var(--ink);
  background: var(--sun-wash);
  border-left: 3px solid var(--sun);
  padding: 18px 24px;
  margin: 16px 0 34px 0;
  max-width: 900px;
}}
.ql-insight b {{ color: var(--sea); font-weight: 500; }}
.ql-insight .ql-tag {{
  font-family: var(--serif);
  color: var(--sun); letter-spacing: .1em;
  margin-right: 8px;
}}

.ql-note {{
  font-family: var(--sans);
  font-size: 14px; line-height: 1.92;
  color: var(--ink-soft);
  background: var(--sea-wash);
  border-left: 3px solid var(--sea-mid);
  padding: 15px 22px;
  margin: 14px 0 26px 0;
  max-width: 900px;
}}
.ql-note b {{ color: var(--sea); font-weight: 500; }}

.ql-warn {{
  font-family: var(--sans);
  font-size: 14px; line-height: 1.9;
  color: var(--ink);
  background: #FBF3E2;
  border-left: 3px solid var(--warn);
  padding: 15px 22px;
  margin: 12px 0;
  max-width: 900px;
}}
.ql-warn b {{ color: #8A6420; font-weight: 500; }}

.ql-caption {{
  font-family: var(--sans);
  font-size: 12.5px; line-height: 1.6;
  color: var(--muted);
  margin: -8px 0 26px 0;
  letter-spacing: .02em;
}}

.insight-box {{
  font-family: var(--sans);
  font-size: 15px; line-height: 1.95;
  color: var(--ink);
  background: var(--sun-wash);
  border-left: 3px solid var(--sun);
  padding: 18px 24px;
  margin: 16px 0 34px 0;
  border-radius: 0;
}}
.insight-box, .insight-box * {{ color: var(--ink) !important; }}
.insight-box b, .insight-box b * {{ color: var(--sea) !important; font-weight: 500; }}

.warning-box {{
  font-family: var(--sans);
  font-size: 14px; line-height: 1.9;
  color: var(--ink);
  background: #FBF3E2;
  border-left: 3px solid var(--warn);
  padding: 15px 22px; margin: 12px 0; border-radius: 0;
}}
.warning-box, .warning-box * {{ color: var(--ink) !important; }}
.warning-box b, .warning-box b * {{ color: #8A6420 !important; font-weight: 500; }}

.danger-box {{
  font-family: var(--sans); font-size: 14px; line-height: 1.9;
  color: var(--ink); background: #FBEDE7;
  border-left: 3px solid var(--danger);
  padding: 15px 22px; margin: 12px 0; border-radius: 0;
}}
.danger-box, .danger-box * {{ color: var(--ink) !important; }}
.danger-box b, .danger-box b * {{ color: var(--danger) !important; font-weight: 500; }}

.success-box {{
  font-family: var(--sans);
  font-size: 14px; line-height: 1.9;
  color: var(--ink);
  background: var(--sea-wash);
  border-left: 3px solid var(--sea-mid);
  padding: 15px 22px; margin: 12px 0; border-radius: 0;
}}
.success-box, .success-box * {{ color: var(--ink) !important; }}
.success-box b, .success-box b * {{ color: var(--sea) !important; font-weight: 500; }}

.insight-box, .warning-box, .danger-box, .success-box {{ max-width: 900px; }}

.ql-hero .ql-hero-kicker, .ql-hero .ql-hero-kicker * {{ color: {PALETTE['sun_soft']} !important; }}
.ql-hero .ql-hero-title, .ql-hero .ql-hero-title * {{ color: #FFFFFF !important; }}
.ql-hero .ql-hero-sub, .ql-hero .ql-hero-sub * {{ color: rgba(255,255,255,.78) !important; }}
.ql-hero .ql-hero-meta .k, .ql-hero .ql-hero-meta .k * {{ color: rgba(255,255,255,.52) !important; }}
.ql-hero .ql-hero-meta .v, .ql-hero .ql-hero-meta .v * {{ color: #FFFFFF !important; }}

.ql-scene .ql-scene-title, .ql-scene .ql-scene-title * {{ color: var(--sea) !important; }}
.ql-scene .ql-scene-lede, .ql-scene .ql-scene-lede * {{ color: var(--muted) !important; }}

.ql-card .v, .ql-card .v * {{ color: var(--sea) !important; }}
.ql-card .k, .ql-card .k * {{ color: var(--muted) !important; }}
.ql-card .d, .ql-card .d * {{ color: var(--ink-soft) !important; }}
.ql-card .u, .ql-card .u * {{ color: var(--ink-soft) !important; }}

.ql-lede, .ql-lede * {{ color: var(--ink-soft) !important; }}
.ql-caption, .ql-caption * {{ color: var(--muted) !important; }}
.ql-footer, .ql-footer * {{ color: var(--muted) !important; }}

.ql-insight, .ql-insight * {{ color: var(--ink) !important; }}
.ql-insight b, .ql-insight b * {{ color: var(--sea) !important; font-weight: 500; }}
.ql-note, .ql-note * {{ color: var(--ink-soft) !important; }}
.ql-note b, .ql-note b * {{ color: var(--sea) !important; font-weight: 500; }}

.ql-brand {{
  padding: 6px 0 18px 0;
  border-bottom: 1px solid var(--line);
  margin-bottom: 18px;
}}
.ql-brand .t {{
  font-family: var(--serif); font-size: 20px;
  line-height: 1.4; letter-spacing: .08em; margin: 0;
}}
.ql-brand .t, .ql-brand .t * {{ color: var(--sea) !important; }}
.ql-brand .s, .ql-brand .s * {{
  font-family: var(--sans); font-size: 11.5px;
  line-height: 1.6; letter-spacing: .16em; margin: 7px 0 0 0;
  color: var(--muted) !important;
}}

.ql-closing {{
  max-width: 900px;
  margin: 3.4rem 0 3rem 0;
  padding: 22px 26px 22px 24px;
  background: var(--sea-wash);
  border-left: 4px solid var(--sea-mid);
}}
.ql-closing .h {{
  font-family: var(--serif); font-size: 16px;
  letter-spacing: .14em; display: block; margin-bottom: 10px;
}}
.ql-closing .h, .ql-closing .h * {{ color: var(--sea) !important; }}
.ql-closing .b {{
  font-family: var(--sans); font-size: 14.5px; line-height: 2.0;
}}
.ql-closing .b, .ql-closing .b * {{ color: var(--ink-soft) !important; }}

.ql-dl {{
  display: inline-block; padding: 10px 22px;
  background: var(--sea); color: #FFFFFF !important;
  border-radius: 2px; text-decoration: none;
  font-family: var(--sans); font-size: 13px; letter-spacing: .06em;
}}
.ql-dl:hover {{ background: var(--sun); }}
.ql-dl:visited, .ql-dl:link {{ color: #FFFFFF !important; }}

.ql-cards {{ display: grid; gap: 1px; background: var(--line); border: 1px solid var(--line); margin: 1.4rem 0 2rem 0; }}.ql-cards.cols4 {{ grid-template-columns: repeat(4, minmax(0,1fr)); }}
.ql-cards.cols3 {{ grid-template-columns: repeat(3, minmax(0,1fr)); }}
.ql-cards.cols2 {{ grid-template-columns: repeat(2, minmax(0,1fr)); }}
.ql-card {{ background: var(--card); padding: 18px 20px; }}
.ql-card .k {{
  font-size: 12px; line-height: 1.5;
  letter-spacing: .12em;
  color: var(--muted); margin: 0 0 10px 0;
}}
.ql-card .v {{
  font-family: var(--serif); font-size: 1.85rem;
  color: var(--sea); margin: 0; line-height: 1.2;
}}
.ql-card .u {{ font-size: 13.5px; color: var(--ink-soft); margin-left: 3px; }}
.ql-card .d {{ font-size: 12.5px; line-height: 1.6; color: var(--ink-soft); margin: 8px 0 0 0; }}

.ql-footer {{
  margin: 4rem -3.2rem 0 -3.2rem;
  padding: 2.2rem 3.2rem;
  background: #F4F2ED;
  border-top: 1px solid var(--line);
  font-family: var(--sans);
  font-size: 12.5px; line-height: 1.7; color: var(--muted);
  letter-spacing: .04em;
}}


@media (max-width: 1200px) {{
  [data-testid="stSidebar"] {{
    min-width: 310px !important; max-width: 310px !important; width: 310px !important;
  }}
  [data-testid="stSidebar"] > div:first-child {{ width: 310px !important; }}
}}


@media (max-width: 900px) {{
  .block-container {{ padding: 0 1.1rem 3rem 1.1rem; }}
  .ql-hero {{ margin: 0 -1.1rem 2rem -1.1rem; padding: 2.6rem 1.1rem 2.2rem 1.1rem; }}
  .ql-hero-title {{ font-size: 2.05rem; }}
  .ql-cards.cols4, .ql-cards.cols3 {{ grid-template-columns: repeat(2, minmax(0,1fr)); }}
  .ql-scene-title {{ font-size: 1.5rem; }}
  .ql-footer {{ margin: 3rem -1.1rem 0 -1.1rem; padding: 1.6rem 1.1rem; }}
}}

/* 图标字体保护：通配符覆盖字体会使连字失效并溢出压字，勿删 */
[data-testid="stIconMaterial"] {{
  font-family: "Material Symbols Rounded" !important;
  font-variant-ligatures: normal !important;
  font-feature-settings: normal !important;
  letter-spacing: normal !important;
  text-transform: none !important;
  overflow: hidden;
}}
</style>
        """,
        unsafe_allow_html=True,
    )


def register_plotly_theme():
    """注册并启用统一图表模板 qilu"""
    tpl = go.layout.Template()
    tpl.layout = go.Layout(
        font=dict(family=FONT_SANS, size=13, color=PALETTE["ink"]),
        title=dict(
            font=dict(family=FONT_SERIF, size=16.5, color=PALETTE["sea"]),
            x=0, xanchor="left", y=0.97, yanchor="top",
        ),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        colorway=CATEGORICAL,
        xaxis=dict(
            showgrid=False, zeroline=False, showline=True,
            linecolor=PALETTE["line"], linewidth=1,
            ticks="outside", tickcolor=PALETTE["line"], ticklen=4,
            tickfont=dict(size=12.5, color=PALETTE["ink_soft"]),
            title=dict(font=dict(size=13, color=PALETTE["muted"])),
        ),
        yaxis=dict(
            showgrid=True, gridcolor="rgba(28,43,51,0.065)", gridwidth=1,
            zeroline=False, showline=False,
            tickfont=dict(size=12.5, color=PALETTE["ink_soft"]),
            title=dict(font=dict(size=13, color=PALETTE["muted"])),
        ),
        legend=dict(
            orientation="h", yanchor="bottom", y=1.02,
            xanchor="left", x=0, bgcolor="rgba(0,0,0,0)",
            font=dict(size=12.5, color=PALETTE["ink_soft"]),
            itemsizing="constant",
            title=dict(text=""),
        ),
        margin=dict(l=6, r=6, t=58, b=6),
        hoverlabel=dict(
            bgcolor="#FFFFFF",
            bordercolor=PALETTE["line"],
            font=dict(family=FONT_SANS, size=12.5, color=PALETTE["ink"]),
        ),
        coloraxis=dict(colorscale=SCALE_TEMP),
        polar=dict(
            bgcolor="rgba(0,0,0,0)",
            radialaxis=dict(gridcolor="rgba(28,43,51,0.09)", linecolor=PALETTE["line"],
                            tickfont=dict(size=11, color=PALETTE["muted"])),
            angularaxis=dict(gridcolor="rgba(28,43,51,0.09)", linecolor=PALETTE["line"],
                             tickfont=dict(size=12.5, color=PALETTE["ink_soft"])),
        ),
    )
    pio.templates["qilu"] = tpl
    pio.templates.default = "qilu"


def hero(kicker, title, subtitle, meta):
    """序章横幅。meta: [(标签, 值), ...]"""
    meta_html = "".join(
        f'<div><span class="k">{k}</span><span class="v">{v}</span></div>'
        for k, v in meta
    )
    st.markdown(
        f"""
<div class="ql-hero">
  <p class="ql-hero-kicker">{kicker}</p>
  <h1 class="ql-hero-title">{title}</h1>
  <p class="ql-hero-sub">{subtitle}</p>
  <div class="ql-hero-meta">{meta_html}</div>
</div>
        """,
        unsafe_allow_html=True,
    )


def scene_header(no, title, lede=""):
    """幕次标题。no 传中文数字，如「壹」"""
    st.markdown(
        f"""
<div class="ql-scene">
  <div class="ql-scene-no">{no}</div>
  <div>
    <h2 class="ql-scene-title">{title}</h2>
    <p class="ql-scene-lede">{lede}</p>
  </div>
</div>
        """,
        unsafe_allow_html=True,
    )


def lede(text):
    """幕次导语"""
    st.markdown(f'<div class="ql-lede">{text}</div>', unsafe_allow_html=True)


def insight(text, tag="结论"):
    """结论框"""
    st.markdown(
        f'<div class="ql-insight"><span class="ql-tag">{tag}</span>{text}</div>',
        unsafe_allow_html=True,
    )


def note(text):
    """说明框"""
    st.markdown(f'<div class="ql-note">{text}</div>', unsafe_allow_html=True)


def warn(text):
    """警示框"""
    st.markdown(f'<div class="ql-warn">{text}</div>', unsafe_allow_html=True)


def caption(text):
    """图注"""
    st.markdown(f'<div class="ql-caption">{text}</div>', unsafe_allow_html=True)


def cards(items, cols=4):
    """数据卡组。items: [(标签, 值, 单位, 说明), ...]"""
    cells = "".join(
        f'<div class="ql-card"><p class="k">{k}</p>'
        f'<p class="v">{v}<span class="u">{u}</span></p>'
        f'<p class="d">{d}</p></div>'
        for k, v, u, d in items
    )
    st.markdown(f'<div class="ql-cards cols{cols}">{cells}</div>', unsafe_allow_html=True)


def footer(text):
    """页脚"""
    st.markdown(f'<div class="ql-footer">{text}</div>', unsafe_allow_html=True)


def brand(title, subtitle):
    """侧边栏品牌标识（写入侧边栏）"""
    st.sidebar.markdown(
        f'<div class="ql-brand"><p class="t">{title}</p>'
        f'<p class="s">{subtitle}</p></div>',
        unsafe_allow_html=True,
    )


def closing(heading, body):
    """尾章结语"""
    st.markdown(
        f'<div class="ql-closing"><span class="h">{heading}</span>'
        f'<span class="b">{body}</span></div>',
        unsafe_allow_html=True,
    )
