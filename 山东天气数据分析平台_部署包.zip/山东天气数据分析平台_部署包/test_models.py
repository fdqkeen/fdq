# -*- coding: utf-8 -*-
"""models.py 单元测试（保留，用于验证算法正确性与边界处理）"""
import numpy as np
import pandas as pd

from models import (
    entropy_weight, topsis, kmeans_cluster,
    linear_trend_forecast, compare_groups, significance_mark,
)

print("=" * 60)
print("测试 1：熵权法")
print("=" * 60)
X = np.array([
    [9, 0, 100],
    [8, 5, 200],
    [6, 10, 300],
], dtype=float)
w, det = entropy_weight(X)
print("权重:", np.round(w, 4), "| 权重和:", round(w.sum(), 6))
assert abs(w.sum() - 1) < 1e-9, "权重和必须为 1"
print("熵值:", np.round(det["entropy"], 4))
print("差异系数:", np.round(det["diff_coef"], 4))
print("OK\n")

print("=" * 60)
print("测试 2：TOPSIS")
print("=" * 60)
benefit = [True, False]
w2 = np.array([0.5, 0.5])
Xb = np.array([
    [9, 1],
    [5, 5],
    [1, 9],
], dtype=float)
C, det2 = topsis(Xb, w2, benefit)
print("贴近度:", np.round(C, 4))
assert C[0] > C[1] > C[2], "排序应为 样本1 > 样本2 > 样本3"
assert C[0] <= 1 and C[2] >= 0
print("正理想解:", np.round(det2["V_pos"], 4))
print("负理想解:", np.round(det2["V_neg"], 4))
print("OK\n")

print("=" * 60)
print("测试 3：K-means 聚类")
print("=" * 60)
rng = np.random.default_rng(42)
c1 = rng.normal([0, 0, 0], 0.3, (20, 3))
c2 = rng.normal([8, 8, 8], 0.3, (20, 3))
c3 = rng.normal([0, 8, 0], 0.3, (20, 3))
Xc = np.vstack([c1, c2, c3])
best_k, labels, scores, Xs = kmeans_cluster(Xc, k_range=(2, 7))
print("轮廓系数:", {k: round(v, 4) for k, v in scores.items()})
print("最优 K =", best_k)
assert best_k == 3, f"应识别出 3 类，实际 {best_k}"
assert len(set(labels)) == 3
print("OK\n")

print("=" * 60)
print("测试 4：线性趋势与预测")
print("=" * 60)
y = np.array([1, 3, 5, 7, 9, 11], dtype=float)
res = linear_trend_forecast(y, periods=3)
print(f"斜率={res['slope']:.4f} 截距={res['intercept']:.4f} R²={res['r2']:.6f}")
print("预测未来3期:", np.round(res["forecast"], 4))
assert abs(res["slope"] - 2) < 1e-9
assert abs(res["intercept"] - 1) < 1e-9
assert abs(res["r2"] - 1) < 1e-9
assert np.allclose(res["forecast"], [13, 15, 17])
print("OK\n")

print("=" * 60)
print("测试 5：两组差异检验")
print("=" * 60)
rng2 = np.random.default_rng(7)
ga = rng2.normal(10, 1, 100)
gb = rng2.normal(13, 1, 100)
r1 = compare_groups(ga, gb)
print(f"[差异明显] 方法={r1['test']} p={r1['p_value']:.3e} 显著={r1['significant']} 标记={significance_mark(r1['p_value'])}")
assert r1["significant"], "应判定为显著"

gc = rng2.normal(10, 1, 100)
gd = rng2.normal(10.05, 1, 100)
r2 = compare_groups(gc, gd)
print(f"[无差异]   方法={r2['test']} p={r2['p_value']:.4f} 显著={r2['significant']} 标记={significance_mark(r2['p_value'])}")

ge = rng2.exponential(1, 100)
gf = rng2.exponential(3, 100)
r3 = compare_groups(ge, gf)
print(f"[非正态]   方法={r3['test']} p={r3['p_value']:.3e} 显著={r3['significant']}")
assert "Mann-Whitney" in r3["test"], "偏态数据应自动选用非参数检验"
print("OK\n")

print("=" * 60)
print("全部测试通过 ✅")
print("=" * 60)
